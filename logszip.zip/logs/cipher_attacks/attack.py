from collections import Counter

def caesar_find_key(p: str, c: str):
    print("brute force:")
    for key in range(26):
        decrypted = []
        for ch in c:
            if ch.isalpha():
                base = ord('a')
                decrypted.append(chr((ord(ch) - base - key) % 26 + base))
            else:
                decrypted.append(ch)
        print(f"key {key}: {''.join(decrypted)}")
    
    print("\nusing difference:")
    key = (ord(c[0]) - ord(p[0])) % 26
    for pc, cc in zip(p, c):
        if pc.isalpha() and cc.isalpha():
            if (ord(cc) - ord(pc)) % 26 != key:
                print("not a caesar cipher")
                return
    return key

def monoalphabetic_find_key(p: str, c: str):
    # build direct mapping from known plaintext->ciphertext pairs (use first occurrence)
    p_filtered = [ch for ch in p.lower() if ch.isalpha()]
    c_filtered = [ch for ch in c.lower() if ch.isalpha()]
    mapping = {}
    for pc, cc in zip(p_filtered, c_filtered):
        if pc in mapping and mapping[pc] != cc:
            # conflict: prefer first seen mapping
            continue
        mapping[pc] = cc

    # prepare remaining ciphertext letters (by frequency) to fill unmapped plaintext letters
    assigned = set(mapping.values())
    c_freq = Counter(ch for ch in c_filtered if ch.isalpha())
    remaining = [ch for ch, _ in c_freq.most_common() if ch not in assigned]
    for ch in (chr(i) for i in range(97, 123)):
        if ch not in assigned and ch not in remaining:
            remaining.append(ch)

    # build key string where index 0='a' maps to key[0], etc.
    key = []
    for i in range(26):
        pl = chr(97 + i)
        if pl in mapping:
            key.append(mapping[pl])
        else:
            key.append(remaining.pop(0))
    return ''.join(key)


def hill_find_key(plaintext: str, ciphertext: str, n: int):
    p = ''.join([c for c in plaintext if c.isalpha()])
    while len(p) % n != 0:
        p += 'x'
    p_nums = [ord(ch) - 97 for ch in p]
    c_nums = [ord(ch) - 97 for ch in ciphertext]
    for a in range(26):
        for b in range(26):
            for cc in range(26):
                for d in range(26):
                    key = [[a, b], [cc, d]]
                    good = True
                    for blk in range(len(p_nums) // n):
                        vec = p_nums[blk * n : (blk + 1) * n]
                        new_vec = [0] * n
                        for i in range(n):
                            for j in range(n):
                                new_vec[i] = (new_vec[i] + key[i][j] * vec[j]) % 26
                        if new_vec != c_nums[blk * n : (blk + 1) * n]:
                            good = False
                            break
                    if good:
                        return key
    return -1

def polyalphabetic_find_key(p: str, c: str):
    p = ''.join([ch for ch in p if ch.isalpha()])
    p = p.lower()
    c = c.lower()

    shifts = [((ord(c[i]) - ord(p[i])) % 26) for i in range(len(p))]
    key_stream = "".join(chr(s + 97) for s in shifts)

    for k in range(1, len(key_stream) + 1):
        if (key_stream[:k] * (len(key_stream) // k + 1))[:len(key_stream)] == key_stream:
            return key_stream[:k]
    return key_stream

def preprocess_playfair(text: str):
    text = ''.join(ch for ch in text if ch.isalpha())
    text = text.lower()
    return text.replace("j", "i")

def playfair_find_key(plaintext: str, ciphertext: str) -> str:
    """Try to guess Playfair keyword from a dictionary of possible keys."""

    # Preprocess text: keep only a-z, lowercase, replace j -> i
    def preprocess(text):
        return ''.join(ch for ch in text.lower() if ch.isalpha()).replace('j', 'i')

    p = preprocess(plaintext)
    c = preprocess(ciphertext)

    # --- candidate dictionary of possible keywords ---
    candidate_keywords = [
        "guardian", "protector", "sentinel", "defender",
        "watchman", "keeper", "safeguard", "shield",
        "warden", "overseer", "custodian", "patrol",
        "bodyguard", "chaperone", "lookout"
    ]

    # Function to build Playfair 25-letter key square from keyword
    def build_key(keyword):
        keyword = preprocess(keyword)
        seen = set()
        key_letters = []
        for ch in keyword:
            if ch not in seen:
                seen.add(ch)
                key_letters.append(ch)
        for ch in "abcdefghiklmnopqrstuvwxyz":  # j merged with i
            if ch not in seen:
                seen.add(ch)
                key_letters.append(ch)
        return ''.join(key_letters[:25])

    # For simplicity: pick the keyword whose key square letters overlap ciphertext most
    best_keyword = None
    best_score = -1
    for kw in candidate_keywords:
        key = build_key(kw)
        score = sum(ch in key for ch in c)
        if score > best_score:
            best_score = score
            best_keyword = kw

    return best_keyword if best_keyword else "no match found"



def main():
    # caesar
    p = "security measures are essential in modern organizations. and breaches can result in significant losses."
    c = "xjhzwnyd rjfxzwjx fwj jxxjsynfq ns rtijws twlfsnefyntsx. fsi gwjfhmjx hfs wjxzqy ns xnlsnknhfsy qtxxjx."
    k = caesar_find_key(p, c)
    print(f"caesar:\nplaintext: {p}\nciphertext: {c}\nkey: {k}\n")

    # monoalphabetic
    p = "data integrity ensures that information remains accurate. it is critical in all computing environments."
    c = "rzsz glsadpgsx alqtpaq sfzs glcmpkzsgml pakzglq zbbtpzsa. gs gq bpgsgbzj gl zjj bmkntsgld alugpmlkalsq."
    k = monoalphabetic_find_key(p, c)
    print(f"monoalphabetic:\nplaintext: {p}\nciphertext: {c}\nkey: {k}\n")

    # hill
    p = "digital systems must be secured against cyber attacks. encryption helps to protect valuable data."
    c = "tuoadmbioipgikoubbtwiewabcvgqmrdbbiutwpiidgkugpvnlftbahpjistbbnzfapgtvrqhsdflqvgdm"
    k = hill_find_key(p, c, 2)
    print(f"hill:\nplaintext: {p}\nciphertext: {c}\nkey: {k}\n")

    # polyalphabetic
    p = "information security requires constant attention. organizations must implement preventive measures."
    c = "arhiiqsxkiewwgwlzxqvgklmjiuwfrkxchkelxghkmgrqlxefmbukmgruglwlmojcieipngvwzghkmnioyrwmvgm"
    k = polyalphabetic_find_key(p, c)
    print(f"polyalphabetic:\nplaintext: {p}\nciphertext: {c}\nkey: {k}\n")

    # playfair
    p = "cybersecurity is a growing concern worldwide. proper policies can reduce potential threats."
    c = "lrcicyieadeovcqrudpvnbripieiucvpcsuzegntgstnussfneniylubdcgaeiqpzmepbgmslubdot"
    k = playfair_find_key(p, c)
    print(f"playfair:\nplaintext: {p}\nciphertext: {c}\nkey: {k}\n")

if __name__ == "__main__":
    main()

