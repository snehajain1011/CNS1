# ===================== ADVANCED MENU-DRIVEN RSA =====================

# GCD
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# Modular inverse (Extended Euclid)
def mod_inverse(e, phi):
    old_r, r = e, phi
    old_s, s = 1, 0
    while r != 0:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_s, s = s, old_s - q * s
    return old_s % phi

# Convert number → letters (Base-26)
def int_to_letters(num):
    res = ""
    while num > 0:
        res = chr((num % 26) + ord('A')) + res
        num //= 26
    return res or "A"

# Convert letters → number
def letters_to_int(s):
    num = 0
    for ch in s:
        num = num * 26 + (ord(ch) - ord('A'))
    return num

# Split message into blocks
def chunk_message(msg, size):
    return [msg[i:i+size] for i in range(0, len(msg), size)]


public_key = None
private_key = None
n = None

while True:
    print("\n===== RSA MENU =====")
    print("1. Generate Keys")
    print("2. Encrypt Message")
    print("3. Decrypt Message")
    print("4. Exit")

    choice = input("Enter choice: ")

    # ================== KEY GENERATION =======================
    if choice == "1":
        p = int(input("Enter prime p: "))
        q = int(input("Enter prime q: "))

        n = p * q
        phi = (p - 1) * (q - 1)

        print(f"\nModulus (n) = {n}")
        print(f"phi(n) = {phi}")

        e = int(input("Enter e (gcd(e, phi)=1): "))

        if gcd(e, phi) != 1:
            print("Invalid e! Must satisfy gcd(e,phi)=1.")
            continue

        d = mod_inverse(e, phi)

        public_key = (e, n)
        private_key = (d, n)

        print("\nPublic Key:", public_key)
        print("Private Key:", private_key)

    # ================== ENCRYPT =======================
    elif choice == "2":
        if public_key is None:
            print("Generate keys first!")
            continue

        msg = input("Enter message to encrypt: ")
        e, n = public_key

        block_size = len(str(n)) // 3
        if block_size < 1:
            block_size = 1

        encrypted_blocks = []

        for block in chunk_message(msg, block_size):
            m = 0
            for ch in block:
                m = m * 256 + ord(ch)   # Pack characters

            c = pow(m, e, n)
            encrypted_blocks.append(int_to_letters(c))

        ciphertext = " ".join(encrypted_blocks)
        print("\nEncrypted (letters only):")
        print(ciphertext)

    # ================== DECRYPT =======================
    elif choice == "3":
        if private_key is None:
            print("Generate keys first!")
            continue

        d, n = private_key

        cipher_input = input("Enter letter-only ciphertext: ").split()

        decrypted_msg = ""

        for block in cipher_input:
            c = letters_to_int(block)
            m = pow(c, d, n)

            temp = ""
            while m > 0:
                temp = chr(m % 256) + temp
                m //= 256

            decrypted_msg += temp

        print("\nDecrypted Message:")
        print(decrypted_msg)

    # ================== EXIT =======================
    elif choice == "4":
        print("Exiting...")
        break

    else:
        print("Invalid choice!")