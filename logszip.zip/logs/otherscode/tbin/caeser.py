# -------------------------------------------
# Caesar Cipher Encryption & Decryption
# -------------------------------------------

def encrypt(text, shift):
    result = ""

    for char in text:
        if char.isalpha():
            shift_base = 65 if char.isupper() else 97
            result += chr((ord(char) - shift_base + shift) % 26 + shift_base)
        else:
            result += char  # Non-alphabetic characters remain same

    return result


def decrypt(cipher_text, shift):
    result = ""

    for char in cipher_text:
        if char.isalpha():
            shift_base = 65 if char.isupper() else 97
            result += chr((ord(char) - shift_base - shift) % 26 + shift_base)
        else:
            result += char

    return result


# -------------------------------------------
# Main Execution (Menu)
# -------------------------------------------
if __name__ == "__main__":
    print("=== Caesar Cipher ===")
    print("1. Encrypt")
    print("2. Decrypt")
    choice = input("Enter choice (1/2): ")

    text = input("Enter text: ")
    shift = int(input("Enter shift value: "))

    if choice == "1":
        encrypted = encrypt(text, shift)
        print("Encrypted Text:", encrypted)

    elif choice == "2":
        decrypted = decrypt(text, shift)
        print("Decrypted Text:", decrypted)

    else:
        print("Invalid choice!")
