# ------------------------------------------------------------
# 1. NORMAL GCD (Brute Force)
# ------------------------------------------------------------
def gcd_normal(a, b):
    gcd = 1
    limit = min(a, b)
    for i in range(1, limit + 1):
        if a % i == 0 and b % i == 0:
            gcd = i
    return gcd


# ------------------------------------------------------------
# 2. EUCLIDEAN ALGORITHM TABLE
# Prints: Q   R1   R2   R
# ------------------------------------------------------------
def gcd_euclidean_table(a, b):
    print("\nQ\tR1\tR2\tR")
    print("-" * 40)

    # Ensure R1 > R2
    R1, R2 = max(a, b), min(a, b)

    while R2 != 0:
        Q = R1 // R2
        R = R1 % R2
        print(f"{Q}\t{R1}\t{R2}\t{R}")

        R1, R2 = R2, R  # Move down

    print(f"-\t{R1}\t{R2}\t-")  # Last row

    return R1


# ------------------------------------------------------------
# 3. EXTENDED EUCLIDEAN TABLE
# Prints: Q R1 R2 R S1 S2 S T1 T2 T
# ------------------------------------------------------------
def extended_euclidean_table(a, b):
    print("\nQ\tR1\tR2\tR\tS1\tS2\tS\tT1\tT2\tT")
    print("-" * 80)

    # Ensure R1 > R2
    R1, R2 = max(a, b), min(a, b)

    # Initial S and T values
    S1, S2 = 1, 0
    T1, T2 = 0, 1

    while R2 != 0:
        Q = R1 // R2
        R = R1 % R2

        S = S1 - Q * S2
        T = T1 - Q * T2

        print(f"{Q}\t{R1}\t{R2}\t{R}\t{S1}\t{S2}\t{S}\t{T1}\t{T2}\t{T}")

        # Move down
        R1, R2 = R2, R
        S1, S2 = S2, S
        T1, T2 = T2, T

    print(f"-\t{R1}\t{R2}\t-\t{S1}\t{S2}\t-\t{T1}\t{T2}\t-")

    return R1, S1, T1   # gcd, x, y


# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------
if __name__ == "__main__":
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))

    print("\n=== GCD METHODS ===")
    print("1) Normal GCD")
    print("2) Euclidean Algorithm Table (Q R1 R2 R)")
    print("3) Extended Euclidean Algorithm Table (Q R1 R2 R S1 S2 S T1 T2 T)")

    choice = input("\nEnter choice: ")

    if choice == '1':
        gcd = gcd_normal(a, b)
        print(f"\nGCD of {a} and {b} = {gcd}")

    elif choice == '2':
        gcd = gcd_euclidean_table(a, b)
        print(f"\nGCD of {a} and {b} = {gcd}")

    elif choice == '3':
        gcd, x, y = extended_euclidean_table(a, b)
        print(f"\nGCD of {a} and {b} = {gcd}")
        print(f"\nEquation: {a}({x}) + {b}({y}) = {gcd}")

    else:
        print("Invalid choice!")
