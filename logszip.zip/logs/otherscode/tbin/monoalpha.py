plain = "abcdefghijklmnopqrstuvwxyz"
cipher = "qwertyuiopasdfghjklzxcvbnm"

def encrypt(text):
    text = text.lower()
    result = ""
    for c in text:
        if c.isalpha():
            idx = plain.index(c)     # find position of letter
            result += cipher[idx]    # substitute
        else:
            result += c
    return result

def decrypt(text):
    text = text.lower()
    result = ""
    for c in text:
        if c.isalpha():
            idx = cipher.index(c)    # reverse lookup
            result += plain[idx]
        else:
            result += c
    return result

# main
print(f"Key: {cipher}")
print("1. Encrypt\n2. Decrypt")
ch = input("Choice: ")
t = input("Enter text: ")

if ch == "1":
    print("Encrypted:", encrypt(t))
elif ch == "2":
    print("Decrypted:", decrypt(t))
else:
    print("Invalid choice!")
