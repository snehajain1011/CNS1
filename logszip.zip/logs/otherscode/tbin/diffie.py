# ------------------------------------------------------------
# Diffie–Hellman Key Exchange (Simple Python Implementation)
# Single Python File
# ------------------------------------------------------------

import random

# Fast modular exponentiation (a^b % mod)
def mod_pow(a, b, mod):
    result = 1
    a = a % mod
    while b > 0:
        if b % 2 == 1:
            result = (result * a) % mod
        a = (a * a) % mod
        b //= 2
    return result

# ------------------------------------------------------------
# Diffie–Hellman
# ------------------------------------------------------------
def diffie_hellman():
    print("=== Diffie–Hellman Key Exchange ===")

    # Public parameters
    p = int(input("Enter a prime number p: "))
    g = int(input("Enter a primitive root g: "))

    print("\nPublic values:")
    print("p =", p)
    print("g =", g)

    # Alice generates private & public keys
    a = random.randint(2, p - 2)
    A = mod_pow(g, a, p)

    # Bob generates private & public keys
    b = random.randint(2, p - 2)
    B = mod_pow(g, b, p)

    print("\n--- Key Generation ---")
    print("Alice's private key a:", a)
    print("Alice's public key  A = g^a mod p =", g, "^", a, "mod", p, "=", A)

    print("\nBob's private key   b:", b)
    print("Bob's public key   B = g^b mod p =", g, "^", b, "mod", p, "=", B)

    # Shared secret calculation
    alice_secret = mod_pow(B, a, p)
    bob_secret = mod_pow(A, b, p)

    print("\n--- Shared Key Computation ---")
    print("Alice computes:")
    print(f"  K_A = B^a mod p = {B}^{a} mod {p} = {alice_secret}")

    print("\nBob computes:")
    print(f"  K_B = A^b mod p = {A}^{b} mod {p} = {bob_secret}")

    print("\nShared Secret Computed by Alice:", alice_secret)
    print("Shared Secret Computed by Bob:  ", bob_secret)

    if alice_secret == bob_secret:
        print("\n✔ SUCCESS: Shared keys match!")
    else:
        print("\n✘ ERROR: Shared keys do not match!")

# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":
    diffie_hellman()
