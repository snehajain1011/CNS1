# ------------------------------------------------------------
# Hill Cipher (3x3 Matrix) – Encryption & Decryption
# Single Python File
# ------------------------------------------------------------

import numpy as np

# Convert character to number (a=0, b=1, ..., z=25)
def char_to_num(c):
    return ord(c) - 97

# Convert number to character
def num_to_char(n):
    return chr(n + 97)

# Clean text (only alphabets)
def clean(text):
    return "".join([c for c in text.lower() if c.isalpha()])

# ------------------------------------------------------------
# Modular inverse for integers
# ------------------------------------------------------------
def mod_inverse(a, m):
    a = a % m
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

# ------------------------------------------------------------
# Modular inverse of 3x3 matrix
# ------------------------------------------------------------
def matrix_mod_inv(matrix, modulus):
    det = int(round(np.linalg.det(matrix)))
    det_mod = det % modulus

    det_inv = mod_inverse(det_mod, modulus)
    if det_inv is None:
        return None

    # Compute adjoint matrix
    adj = np.round(det * np.linalg.inv(matrix)).astype(int)
    return (det_inv * adj) % modulus

# ------------------------------------------------------------
# Encryption
# ------------------------------------------------------------
def encrypt(plaintext, key_matrix):
    plaintext = clean(plaintext)

    # Pad so length is multiple of 3
    while len(plaintext) % 3 != 0:
        plaintext += "x"

    cipher = ""
    for i in range(0, len(plaintext), 3):
        block = np.array([
            [char_to_num(plaintext[i])],
            [char_to_num(plaintext[i+1])],
            [char_to_num(plaintext[i+2])]
        ])

        result = np.dot(key_matrix, block) % 26

        cipher += num_to_char(result[0][0])
        cipher += num_to_char(result[1][0])
        cipher += num_to_char(result[2][0])

    return cipher

# ------------------------------------------------------------
# Decryption
# ------------------------------------------------------------
def decrypt(ciphertext, key_matrix):
    ciphertext = clean(ciphertext)

    inv_matrix = matrix_mod_inv(key_matrix, 26)
    if inv_matrix is None:
        raise ValueError("Key matrix is not invertible modulo 26!")

    plain = ""
    for i in range(0, len(ciphertext), 3):
        block = np.array([
            [char_to_num(ciphertext[i])],
            [char_to_num(ciphertext[i+1])],
            [char_to_num(ciphertext[i+2])]
        ])

        result = np.dot(inv_matrix, block) % 26

        plain += num_to_char(result[0][0])
        plain += num_to_char(result[1][0])
        plain += num_to_char(result[2][0])

    return plain

# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=== Hill Cipher (3x3 Matrix) ===")
    print("1. Encrypt")
    print("2. Decrypt")

    choice = input("Enter choice (1/2): ")

    print("\nEnter 9 numbers for 3x3 key matrix (row-wise).")
    print("Example: 6 24 1 13 16 10 20 17 15")
    
    vals = list(map(int, input("Enter key matrix values: ").split()))
    if len(vals) != 9:
        print("Error: provide exactly 9 integers!")
        exit()

    key_matrix = np.array(vals).reshape(3, 3)
    text = input("\nEnter text: ")

    try:
        if choice == "1":
            result = encrypt(text, key_matrix)
            print("\nEncrypted Text:", result)

        elif choice == "2":
            result = decrypt(text, key_matrix)
            print("\nDecrypted Text:", result)

        else:
            print("Invalid choice!")

    except ValueError as e:
        print("\nError:", e)
