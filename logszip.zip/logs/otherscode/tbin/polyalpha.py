# --------------------------------------------------------
# Generate repeated key ONLY for alphabetic characters
# --------------------------------------------------------
def generate_key(text, key):
    key = key.lower()
    new_key = ""
    j = 0

    for char in text:
        if char.isalpha():   # Only map letters
            new_key += key[j % len(key)]
            j += 1
        else:
            new_key += char  # Keep spaces/punctuation unchanged
    return new_key


# --------------------------------------------------------
# Encrypt (Vigenère)
# --------------------------------------------------------
def encrypt(text, key):
    text = text.lower()
    key = generate_key(text, key)
    cipher = ""

    for t, k in zip(text, key):
        if t.isalpha():
            shift = (ord(t) - 97 + ord(k) - 97) % 26
            cipher += chr(shift + 97)
        else:
            cipher += t
    return cipher


# --------------------------------------------------------
# Decrypt (Vigenère)
# --------------------------------------------------------
def decrypt(cipher, key):
    cipher = cipher.lower()
    key = generate_key(cipher, key)
    plain = ""

    for c, k in zip(cipher, key):
        if c.isalpha():
            shift = (ord(c) - 97 - (ord(k) - 97)) % 26
            plain += chr(shift + 97)
        else:
            plain += c
    return plain


# --------------------------------------------------------
# Main Program
# --------------------------------------------------------
if __name__ == "__main__":
    print("=== Vigenère Cipher ===")
    print("1. Encrypt")
    print("2. Decrypt")

    choice = input("Enter choice (1/2): ")

    text = input("Enter text: ")
    key = input("Enter key: ")

    if not key.isalpha():
        print("Key must contain only letters!")
        exit()

    if choice == "1":
        print("\nEncrypted Text:", encrypt(text, key))
    elif choice == "2":
        print("\nDecrypted Text:", decrypt(text, key))
    else:
        print("Invalid choice!")
