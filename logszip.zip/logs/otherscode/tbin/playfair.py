# ------------------------------------------------------------
# Playfair Cipher – Encryption & Decryption
# Single Python File
# ------------------------------------------------------------

import string

# ------------------------------------------------------------
# Create 5x5 Playfair key matrix
# ------------------------------------------------------------
def generate_key_matrix(key):
    key = key.lower().replace("j", "i")
    matrix = []
    used = set()

    # Insert key characters
    for char in key:
        if char.isalpha() and char not in used:
            matrix.append(char)
            used.add(char)

    # Insert remaining alphabets (without j)
    for char in string.ascii_lowercase:
        if char not in used and char != "j":
            matrix.append(char)
            used.add(char)

    # Convert to 5x5 matrix
    key_matrix = [matrix[i:i+5] for i in range(0, 25, 5)]
    return key_matrix

# ------------------------------------------------------------
# Find letter position in matrix
# ------------------------------------------------------------
def find_position(matrix, letter):
    if letter == "j":
        letter = "i"
    for r in range(5):
        for c in range(5):
            if matrix[r][c] == letter:
                return r, c
    return None

# ------------------------------------------------------------
# Prepare plaintext by breaking into digraphs
# ------------------------------------------------------------
def prepare_text(text):
    text = text.lower().replace("j", "i")
    text = "".join([c for c in text if c.isalpha()])

    prepared = ""
    i = 0

    while i < len(text):
        a = text[i]
        b = ""

        if i + 1 < len(text):
            b = text[i+1]

        if a == b:  
            prepared += a + "x"
            i += 1
        else:
            if b == "":
                prepared += a + "x"
                i += 1
            else:
                prepared += a + b
                i += 2

    return prepared

# ------------------------------------------------------------
# Encryption
# ------------------------------------------------------------
def encrypt(plaintext, key_matrix):
    plaintext = prepare_text(plaintext)
    cipher = ""

    for i in range(0, len(plaintext), 2):
        a = plaintext[i]
        b = plaintext[i+1]

        r1, c1 = find_position(key_matrix, a)
        r2, c2 = find_position(key_matrix, b)

        # Case 1: Same row
        if r1 == r2:
            cipher += key_matrix[r1][(c1 + 1) % 5]
            cipher += key_matrix[r2][(c2 + 1) % 5]

        # Case 2: Same column
        elif c1 == c2:
            cipher += key_matrix[(r1 + 1) % 5][c1]
            cipher += key_matrix[(r2 + 1) % 5][c2]

        # Case 3: Rectangle swap
        else:
            cipher += key_matrix[r1][c2]
            cipher += key_matrix[r2][c1]

    return cipher

# ------------------------------------------------------------
# Decryption
# ------------------------------------------------------------
def decrypt(ciphertext, key_matrix):
    ciphertext = ciphertext.lower()
    plaintext = ""

    for i in range(0, len(ciphertext), 2):
        a = ciphertext[i]
        b = ciphertext[i+1]

        r1, c1 = find_position(key_matrix, a)
        r2, c2 = find_position(key_matrix, b)

        # Case 1: Same row (shift left)
        if r1 == r2:
            plaintext += key_matrix[r1][(c1 - 1) % 5]
            plaintext += key_matrix[r2][(c2 - 1) % 5]

        # Case 2: Same column (shift up)
        elif c1 == c2:
            plaintext += key_matrix[(r1 - 1) % 5][c1]
            plaintext += key_matrix[(r2 - 1) % 5][c2]

        # Case 3: Rectangle swap
        else:
            plaintext += key_matrix[r1][c2]
            plaintext += key_matrix[r2][c1]

    return plaintext

# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=== Playfair Cipher ===")
    print("1. Encrypt")
    print("2. Decrypt")

    choice = input("Enter choice (1/2): ")
    key = input("Enter key: ")

    key_matrix = generate_key_matrix(key)

    print("\nKey Matrix:")
    for row in key_matrix:
        print(row)

    text = input("\nEnter text: ")

    if choice == "1":
        result = encrypt(text, key_matrix)
        print("\nEncrypted Text:", result)

    elif choice == "2":
        result = decrypt(text, key_matrix)
        print("\nDecrypted Text:", result)

    else:
        print("Invalid choice!")
