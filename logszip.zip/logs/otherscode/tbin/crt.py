# ------------------------------------------------------------
# Extended Euclidean Algorithm
# ------------------------------------------------------------
def extended_euclidean(a, b):
    if b == 0:
        return a, 1, 0
    gcd, x1, y1 = extended_euclidean(b, a % b)
    x = y1
    y = x1 - (a // b) * y1
    return gcd, x, y

# ------------------------------------------------------------
# Modular inverse using Extended Euclidean
# ------------------------------------------------------------
def mod_inverse(a, m):
    gcd, x, y = extended_euclidean(a, m)
    if gcd != 1:
        return None
    return x % m

# ------------------------------------------------------------
# Chinese Remainder Theorem with full expanded explanation
# ------------------------------------------------------------
def chinese_remainder_verbose(a_list, m_list):

    print("\n=== Given Congruences ===")
    for i in range(len(a_list)):
        print(f"X ≡ {a_list[i]} (mod {m_list[i]})")

    # Step 1: M = product of moduli
    M = 1
    for m in m_list:
        M *= m

    print("\nM = ", end="")
    print(" × ".join(str(m) for m in m_list), end="")
    print(f" = {M}\n")

    Mi_list = []
    inv_list = []

    # Step 2: Compute Mi and Mi inverse
    for i, mi in enumerate(m_list):
        Mi = M // mi
        Mi_list.append(Mi)

        inv = mod_inverse(Mi, mi)
        inv_list.append(inv)

        print(f"M{i+1} = M / m{i+1} = {M} / {mi} = {Mi}")
        print(f"Inverse of M{i+1} mod m{i+1} = inverse({Mi} mod {mi}) = {inv}\n")

    # Step 3: Show full CRT formula
    print("\n=== CRT Formula ===")
    print("X = ", end="")
    formula_parts = []
    for i in range(len(a_list)):
        part = f"{a_list[i]}·{Mi_list[i]}·{inv_list[i]}"
        formula_parts.append(part)
    print(" + ".join(formula_parts), end="")
    print(f"  (mod {M})\n")

    # Step 4: Compute final result
    X = 0
    for ai, Mi, inv in zip(a_list, Mi_list, inv_list):
        X += ai * Mi * inv

    X = X % M
    return X


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=== Chinese Remainder Theorem (Detailed Steps) ===")

    n = int(input("Enter number of congruences: "))

    a_list = []
    m_list = []

    for i in range(n):
        print(f"\nEquation {i+1}: X ≡ ai (mod mi)")
        ai = int(input("Enter ai: "))
        mi = int(input("Enter mi: "))
        a_list.append(ai)
        m_list.append(mi)

    X = chinese_remainder_verbose(a_list, m_list)

    print("=== FINAL ANSWER ===")
    print(f"X = {X}")
