# ------------------------------------------------------------
# Extended Euclidean Table for Modular Inverse
# Format: Q  R1  R2  R  T1  T2  T
# R1 = a, R2 = m (we find inverse of a mod m)
# ------------------------------------------------------------

def mod_inverse_table(a, m):
    print("\nQ\tR1\tR2\tR\tT1\tT2\tT")
    print("-" * 60)

    R1, R2 = a, m   # R1 = number, R2 = modulus
    T1, T2 = 1, 0   # Start for inverse calculation

    while R2 != 0:
        Q = R1 // R2
        R = R1 % R2
        T = T1 - Q * T2

        print(f"{Q}\t{R1}\t{R2}\t{R}\t{T1}\t{T2}\t{T}")

        # Move forward
        R1, R2 = R2, R
        T1, T2 = T2, T

    print(f"-\t{R1}\t{R2}\t-\t{T1}\t{T2}\t-")

    # If gcd != 1 → inverse doesn't exist
    if R1 != 1:
        return None

    # T1 is the inverse, make it positive
    return T1 % m


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":
    a = int(input("Enter number (whose inverse you want): "))
    m = int(input("Enter modulus m: "))

    inv = mod_inverse_table(a, m)

    if inv is None:
        print(f"\nInverse of {a} mod {m} does NOT exist (gcd ≠ 1)")
    else:
        print(f"\nInverse of {a} mod {m} = {inv}")
        print(f"Check: ({a} * {inv}) % {m} = {(a * inv) % m}")
