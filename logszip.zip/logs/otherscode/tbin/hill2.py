# ------------------------------------------------------------
# Hill Cipher (2x2 Matrix) – Encryption & Decryption
# Single Python File
# ------------------------------------------------------------

import numpy as np

# Convert character to number (a=0, b=1, ..., z=25)
def char_to_num(c):
    return ord(c) - 97

# Convert number to character
def num_to_char(n):
    return chr(n + 97)

# Clean text (remove non-letters)
def clean(text):
    text = text.lower()
    return "".join([c for c in text if c.isalpha()])

# ------------------------------------------------------------
# Encryption
# ------------------------------------------------------------
def encrypt(plaintext, key_matrix):
    plaintext = clean(plaintext)

    # If odd length, add padding
    if len(plaintext) % 2 != 0:
        plaintext += "x"

    cipher = ""
    for i in range(0, len(plaintext), 2):
        pair = np.array([[char_to_num(plaintext[i])],
                         [char_to_num(plaintext[i+1])]])

        # Multiply with key matrix mod 26
        result = np.dot(key_matrix, pair) % 26
        cipher += num_to_char(result[0][0])
        cipher += num_to_char(result[1][0])

    return cipher

# ------------------------------------------------------------
# Decryption
# ------------------------------------------------------------
def decrypt(ciphertext, key_matrix):
    ciphertext = clean(ciphertext)

    # Find inverse of key matrix mod 26
    det = int(np.round(np.linalg.det(key_matrix)))
    det_mod_inv = mod_inverse(det % 26, 26)

    if det_mod_inv is None:
        raise ValueError("Key matrix is not invertible modulo 26!")

    # Inverse matrix formula for 2x2
    adj = np.array([[key_matrix[1][1], -key_matrix[0][1]],
                    [-key_matrix[1][0], key_matrix[0][0]]])

    inv_matrix = (det_mod_inv * adj) % 26

    plain = ""
    for i in range(0, len(ciphertext), 2):
        pair = np.array([[char_to_num(ciphertext[i])],
                         [char_to_num(ciphertext[i+1])]])

        result = np.dot(inv_matrix, pair) % 26
        plain += num_to_char(result[0][0])
        plain += num_to_char(result[1][0])

    return plain

# ------------------------------------------------------------
# Compute modular inverse
# ------------------------------------------------------------
def mod_inverse(a, m):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

# ------------------------------------------------------------
# MAIN PROGRAM
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=== Hill Cipher (2x2 Matrix) ===")
    print("1. Encrypt")
    print("2. Decrypt")

    choice = input("Enter choice (1/2): ")

    print("\nEnter 4 numbers for 2x2 key matrix (row-wise).")
    print("Example for matrix [[3,3],[2,5]] enter: 3 3 2 5")
    a, b, c, d = map(int, input("Enter key matrix values: ").split())
    key_matrix = np.array([[a, b], [c, d]])

    text = input("\nEnter text: ")

    try:
        if choice == "1":
            result = encrypt(text, key_matrix)
            print("\nEncrypted Text:", result)

        elif choice == "2":
            result = decrypt(text, key_matrix)
            print("\nDecrypted Text:", result)

        else:
            print("Invalid choice!")

    except ValueError as e:
        print("\nError:", e)
