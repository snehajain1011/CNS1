# ------------------------------------------------------------
# Simplified Rail Fence Cipher (Encrypt + Decrypt)
# ------------------------------------------------------------

def encrypt(text, rails):
    if rails <= 1:
        return text

    fence = [''] * rails
    row, step = 0, 1

    for ch in text:
        fence[row] += ch
        if row == 0:
            step = 1
        elif row == rails - 1:
            step = -1
        row += step

    return ''.join(fence)


def decrypt(cipher, rails):
    if rails <= 1:
        return cipher

    # Determine zigzag pattern of rows
    pattern = []
    row, step = 0, 1
    for _ in cipher:
        pattern.append(row)
        if row == 0:
            step = 1
        elif row == rails - 1:
            step = -1
        row += step

    # Count characters in each rail
    rail_counts = [pattern.count(r) for r in range(rails)]

    # Split cipher into rails
    rails_text = []
    idx = 0
    for count in rail_counts:
        rails_text.append(cipher[idx:idx + count])
        idx += count

    # Read rails in zigzag order
    pointers = [0] * rails
    result = []

    for r in pattern:
        result.append(rails_text[r][pointers[r]])
        pointers[r] += 1

    return ''.join(result)


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=== Simple Rail Fence Cipher ===")
    print("1. Encrypt")
    print("2. Decrypt")

    choice = input("Enter choice (1/2): ")
    rails = int(input("Enter number of rails: "))
    text = input("Enter text: ")

    if choice == "1":
        print("\nEncrypted:", encrypt(text, rails))
    elif choice == "2":
        print("\nDecrypted:", decrypt(text, rails))
    else:
        print("Invalid choice!")
