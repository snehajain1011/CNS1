import socket
import threading

# ---------- RSA Utility ----------
def power(base, expo, mod):
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    for d in range(2, phi):
        if (e * d) % phi == 1:
            return d
    return -1

def generate_keys(user):
    if user == "alice":
        p, q = 61, 53
    else:
        p, q = 71, 67
    n = p*q
    phi = (p-1)*(q-1)
    for e in range(2, phi):
        if gcd(e, phi) == 1:
            break
    d = mod_inverse(e, phi)
    return (e, d, n)

def rsa_encrypt(m, e, n):
    return power(m, e, n)

def rsa_decrypt(c, d, n):
    return power(c, d, n)

# ---------- Vigenère ----------
def vigenere_encrypt(text, key):
    out = []
    L = len(key)
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % L]) - ord('a')
            out.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            out.append(ch)
    return ''.join(out)

def vigenere_decrypt(text, key):
    out = []
    L = len(key)
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % L]) - ord('a')
            out.append(chr((ord(ch) - base - shift) % 26 + base))
        else:
            out.append(ch)
    return ''.join(out)


# ---------- Client Setup ----------
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 6000))

username = input("Enter username (alice/bob): ").strip().lower()
e, d, n = generate_keys(username)
public_key = (e, n)
private_key = (d, n)

client.send(f"REGISTER {username} {e} {n}".encode())

other_pubkey = None
symmetric_keys = {}
chosen_key = None

# ---------- Receiver Thread ----------
def receive_messages():
    global other_pubkey

    while True:
        try:
            raw = client.recv(8192).decode()
            if not raw:
                continue

            msg = raw.strip("\n")   # do NOT remove spaces

            # ----- Received Public Key -----
            if msg.startswith("PUBKEY"):
                _, target, e_str, n_str = msg.split()
                other_pubkey = (int(e_str), int(n_str))
                print(f"[INFO] Received {target}'s public key")

            # ----- Received Symmetric Key -----
            elif msg.startswith("SET_KEY"):
                try:
                    parts = msg.split(" ", 2)
                    sender = parts[1]
                    cipher_str = parts[2]

                    nums = list(map(int, cipher_str.split()))
                    key = ''.join(chr(rsa_decrypt(x, *private_key) + ord('a')) for x in nums)

                    symmetric_keys[sender] = key
                    print(f"[INFO] Symmetric key received from {sender}: {key}")

                except Exception as e:
                    print("[SET_KEY ERROR]", e, msg)

            # ----- Received Encrypted Message -----
            elif msg.startswith("FROM"):
                try:
                    parts = msg.split(" ", 2)
                    sender = parts[1]
                    cipher = parts[2]

                    if sender not in symmetric_keys:
                        print("[ERROR] No symmetric key for this sender")
                        continue

                    key = symmetric_keys[sender]
                    plaintext = vigenere_decrypt(cipher, key)

                    print(f"\n[Message from {sender}]")
                    print("Encrypted:", cipher)
                    print("Decrypted:", plaintext, "\n")

                except Exception as e:
                    print("[FROM ERROR]", e, msg)

            else:
                print(msg)

        except Exception as e:
            print("[Receiver Error]", e)
            break


threading.Thread(target=receive_messages, daemon=True).start()


# ---------- Commands ----------
def handle_get(target):
    client.send(f"GET {target}".encode())

def handle_set_key(target):
    global chosen_key

    chosen_key = input("Enter symmetric key: ").strip().lower()

    if not other_pubkey:
        print("[ERROR] GET <user> first")
        return

    nums = [rsa_encrypt(ord(c)-97, *other_pubkey) for c in chosen_key]
    cipher = " ".join(map(str, nums))

    client.send(f"SET_KEY {target} {cipher}".encode())
    print("[INFO] Key sent")

def handle_send(target):
    if chosen_key is None:
        print("[ERROR] Use SET_KEY first")
        return

    msg = input("Enter message: ")
    encrypted = vigenere_encrypt(msg, chosen_key)

    print("Encrypted:", encrypted)
    client.send(f"SEND {target} {encrypted}".encode())


# ---------- Main Loop ----------
while True:
    cmd = input("Enter command (GET / SET_KEY / SEND): ")

    try:
        op, target = cmd.split()
    except:
        print("Invalid command")
        continue

    if op.upper() == "GET":
        handle_get(target)

    elif op.upper() == "SET_KEY":
        handle_set_key(target)

    elif op.upper() == "SEND":
        handle_send(target)

    else:
        print("Unknown command")
