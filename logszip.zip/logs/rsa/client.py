import socket
import threading
import random
import string

def power(base: int, expo: int, mod: int) -> int:
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e: int, phi: int) -> int:
    for d in range(2, phi):
        if (e * d) % phi == 1:
            return d
    return -1

def generate_keys(user: str):
    if user.lower() == "alice":
        p, q = 61, 53
    else:
        p, q = 71, 67
    n = p * q
    phi = (p - 1) * (q - 1)
    for e in range(2, phi):
        if gcd(e, phi) == 1:
            break
    d = mod_inverse(e, phi)
    return (e, d, n)

def rsa_encrypt(m: int, e: int, n: int) -> int:
    return power(m, e, n)

def rsa_decrypt(c: int, d: int, n: int) -> int:
    return power(c, d, n)


def vigenere_encrypt(plaintext: str, key: str) -> str:
    ciphertext = []
    key_len = len(key)
    for i, ch in enumerate(plaintext):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % key_len].lower()) - ord('a')
            ciphertext.append(chr((ord(ch) - base + shift) % 26 + base))
        else:
            ciphertext.append(ch)
    return ''.join(ciphertext)

def vigenere_decrypt(ciphertext: str, key: str) -> str:
    plaintext = []
    key_len = len(key)
    for i, ch in enumerate(ciphertext):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % key_len].lower()) - ord('a')
            plaintext.append(chr((ord(ch) - base - shift) % 26 + base))
        else:
            plaintext.append(ch)
    return ''.join(plaintext)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 6000))

username = input("Enter username (alice/bob): ").strip().lower()
e, d, n = generate_keys(username)
public_key = (e, n)
private_key = (d, n)

client.send(f"REGISTER {username} {e} {n}".encode())

other_pubkey = None
symmetric_keys = {}
chosen_key = None


def receive_messages():
    global other_pubkey, symmetric_keys
    while True:
        try:
            msg = client.recv(8192).decode().strip()
            if not msg:
                break
            if msg.startswith("PUBKEY"):
                _, target, e_str, n_str = msg.split()
                other_pubkey = (int(e_str), int(n_str))
                print(f"[INFO] Stored {target}'s public key: {other_pubkey}")
            elif msg.startswith("SET_KEY"):
                _, sender, rsa_cipher_str = msg.split(maxsplit=2)
                cipher_numbers = list(map(int, rsa_cipher_str.split()))
                key = ''.join(chr(rsa_decrypt(c, *private_key) + ord('a')) for c in cipher_numbers)
                symmetric_keys[sender] = key
                print(f"[INFO] Stored symmetric key from {sender} (length={len(key)})")
            elif msg.startswith("FROM"):
                _, sender, cipher_text = msg.split(maxsplit=2)
                if sender not in symmetric_keys:
                    print(f"[ERROR] No symmetric key for {sender}")
                    continue
                key = symmetric_keys[sender]
                plaintext = vigenere_decrypt(cipher_text, key)
                filename = f"received_from_{sender}.txt"
                with open(filename, "w", encoding="utf-8") as f:
                    f.write(plaintext)
                print(f"[Message from {sender}] saved to {filename}")
            else:
                print(msg)
        except Exception as ex:
            print("[Receiver Error]", ex)
            break

threading.Thread(target=receive_messages, daemon=True).start()


def handle_get(target: str):
    client.send(f"GET {target}".encode())

def handle_set_key(target: str):
    global chosen_key
    chosen_key = ''.join(random.choices(string.ascii_lowercase, k=250))
    if other_pubkey:
        cipher_numbers = [rsa_encrypt(ord(c)-ord('a'), *other_pubkey) for c in chosen_key]
        cipher_str = ' '.join(map(str, cipher_numbers))
        client.sendall(f"SET_KEY {target} {cipher_str}".encode())
        print(f"[INFO] Sent symmetric key to {target} (length={len(chosen_key)})")
    else:
        print("[ERROR] No public key of target. Use GET <user> first.")

def handle_send_file(target: str, filename: str):
    if chosen_key is None:
        print("[ERROR] No symmetric key set yet. Use SET_KEY first.")
        return
    try:
        with open(filename, "r", encoding="utf-8") as f:
            message = f.read()
    except FileNotFoundError:
        print(f"[ERROR] File not found: {filename}")
        return
    cipher_text = vigenere_encrypt(message, chosen_key)
    client.sendall(f"SEND {target} {cipher_text}".encode())
    print(f"[INFO] Sent file {filename} to {target}")


while True:
    cmd = input("Enter command (GET <user> / SET_KEY <user> / SEND_FILE <user> <filename>): ").strip()
    if cmd.startswith("GET"):
        _, target = cmd.split()
        handle_get(target)
    elif cmd.startswith("SET_KEY"):
        _, target = cmd.split()
        handle_set_key(target)
    elif cmd.startswith("SEND_FILE"):
        _, target, filename = cmd.split()
        handle_send_file(target, filename)
    else:
        client.send(cmd.encode())
