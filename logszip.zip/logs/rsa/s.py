import socket

# ---------- RSA UTILITY (your logic) ----------
def power(base, expo, mod):
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    for d in range(2, phi):
        if (e * d) % phi == 1:
            return d
    return -1

def generate_keys():
    p, q = 61, 53          # small primes like your code
    n = p * q
    phi = (p - 1)*(q - 1)

    # pick e
    for e in range(2, phi):
        if gcd(e, phi) == 1:
            break

    d = mod_inverse(e, phi)
    return e, d, n

def rsa_decrypt(c, d, n):
    return power(c, d, n)

# ---------- SERVER ----------
e, d, n = generate_keys()
print("SERVER PUBLIC KEY:", e, n)

s = socket.socket()
s.bind(("0.0.0.0", 5000))
s.listen(1)
print("Server listening...")

while True:
    conn, addr = s.accept()
    print("Client connected:", addr)

    conn.send(f"{e} {n}".encode())      # send public key

    data = conn.recv(8192).decode()
    cipher_values = list(map(int, data.split()))

    decrypted_chars = [chr(rsa_decrypt(c, d, n)) for c in cipher_values]
    plaintext = "".join(decrypted_chars)

    print("Decrypted message:", plaintext)
    conn.close()
