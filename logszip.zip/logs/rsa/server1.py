import socket
import threading

clients = {}
public_keys = {}

def handle_client(conn, addr):
    name = None
    while True:
        try:
            msg = conn.recv(65536).decode()
            if not msg:
                break

            parts = msg.strip().split(maxsplit=3)
            cmd = parts[0].upper()

            # ---------------- REGISTER ----------------
            if cmd == "REGISTER":
                if len(parts) < 4:
                    conn.send("ERROR REGISTER FORMAT\n".encode())
                    continue
                _, name, e, n = parts
                public_keys[name] = (int(e), int(n))
                clients[name] = conn
                conn.send(f"[SERVER] Registered as {name}\n".encode())
                print(f"[SERVER] {name} registered")

            # ---------------- GET PUBKEY ----------------
            elif cmd == "GET":
                if len(parts) < 2:
                    conn.send("ERROR GET FORMAT\n".encode())
                    continue

                target = parts[1]
                if target in public_keys:
                    e, n = public_keys[target]
                    conn.send(f"PUBKEY {target} {e} {n}\n".encode())
                else:
                    conn.send("ERROR No such user\n".encode())

            # ---------------- SET_KEY ----------------
            elif cmd == "SET_KEY":
                try:
                    target = msg.split(" ", 2)[1]
                    cipher = msg.split(" ", 2)[2].strip()
                except:
                    conn.send("ERROR SET_KEY FORMAT\n".encode())
                    continue

                if target in clients:
                    clients[target].send(f"SET_KEY {name} {cipher}\n".encode())
                    print(f"[SERVER] Sent symmetric key from {name} to {target}")
                else:
                    conn.send("ERROR Target not online\n".encode())

            # ---------------- SEND MESSAGE ----------------
            elif cmd == "SEND":
                try:
                    target = msg.split(" ", 2)[1]
                    ciphertext = msg.split(" ", 2)[2].strip()
                except:
                    conn.send("ERROR SEND FORMAT\n".encode())
                    continue

                if target in clients:
                    clients[target].send(f"FROM {name} {ciphertext}\n".encode())
                    print(f"[SERVER] Forwarded message {name} → {target}")
                else:
                    conn.send("ERROR Target not online\n".encode())

            else:
                conn.send("ERROR Unknown command\n".encode())

        except Exception as e:
            print("[SERVER ERROR]", e)
            break

    if name in clients:
        del clients[name]
    conn.close()


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 6000))
    server.listen(5)
    print("[SERVER] Listening on 127.0.0.1:6000")

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()


start_server()
