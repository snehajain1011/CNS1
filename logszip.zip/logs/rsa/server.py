import socket
import threading

clients = {}       
public_keys = {}   

def handle_client(conn, addr):
    name = None
    while True:
        try:
            msg = conn.recv(65536).decode()
            if not msg:
                break

            parts = msg.strip().split(maxsplit=2)
            if len(parts) == 0:
                continue
            cmd = parts[0].upper()

            if cmd == "REGISTER":
                rest = msg.strip().split()
                if len(rest) < 4:
                    conn.send("ERROR Malformed REGISTER\n".encode())
                    continue
                _, name, e_str, n_str = rest[:4]
                public_keys[name] = (int(e_str), int(n_str))
                clients[name] = conn
                conn.send(f"[SERVER] Registered as {name}\n".encode())
                print(f"[SERVER] {name} registered with key {public_keys[name]}")

            elif cmd == "GET":
                if len(parts) < 2:
                    conn.send("ERROR Malformed GET\n".encode())
                    continue
                target = parts[1]
                if target in public_keys:
                    e, n = public_keys[target]
                    conn.send(f"PUBKEY {target} {e} {n}\n".encode())
                else:
                    conn.send(f"ERROR No such user {target}\n".encode())

            elif cmd == "SET_KEY":
                if len(parts) < 3:
                    conn.send("ERROR Malformed SET_KEY\n".encode())
                    continue
                target = parts[1]
                rsa_cipher = parts[2]
                if target in clients:
                    try:
                        clients[target].sendall(f"SET_KEY {name} {rsa_cipher}\n".encode())
                        print(f"[SERVER] {name} -> {target} | Encrypted symmetric key")
                    except:
                        conn.send(f"ERROR Could not deliver key to {target}\n".encode())
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            elif cmd == "SEND":
                if len(parts) < 3:
                    conn.send("ERROR Malformed SEND\n".encode())
                    continue
                target = parts[1]
                ciphertext = parts[2]
                if target in clients:
                    try:
                        clients[target].sendall(f"FROM {name} {ciphertext}\n".encode())
                    except:
                        conn.send(f"ERROR Could not deliver to {target}\n".encode())
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            else:
                conn.send("ERROR Unknown command\n".encode())

        except Exception as e:
            print(f"[SERVER] Error: {e}")
            break

    if name and name in clients:
        del clients[name]
    conn.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 6000))
    server.listen(5)
    print("[SERVER] Listening on 127.0.0.1:6000")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_server()
