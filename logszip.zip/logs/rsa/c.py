import socket

# ---------- RSA utility ----------
def power(base, expo, mod):
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def rsa_encrypt(m, e, n):
    return power(m, e, n)

# ---------- CLIENT ----------
s = socket.socket()
s.connect(("127.0.0.1", 5000))

# receive public key
data = s.recv(1024).decode()
e, n = map(int, data.split())
print("Received public key:", e, n)

msg = input("Enter message: ")

cipher_values = [rsa_encrypt(ord(c), e, n) for c in msg]
cipher_text = " ".join(map(str, cipher_values))

s.send(cipher_text.encode())
print("Encrypted message sent.")
s.close()
