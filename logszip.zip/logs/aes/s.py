import socket
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

def get_key(prompt):
    while True:
        key = input(prompt)
        if len(key) in (16, 24, 32):
            return key.encode()
        print("Key must be 16, 24, or 32 characters!")

def get_iv(prompt):
    while True:
        iv = input(prompt)
        if len(iv) == 16:
            return iv.encode()
        print("IV must be exactly 16 characters!")

def main():
    key = get_key("Enter AES key (16/24/32 chars): ")
    iv  = get_iv("Enter IV (16 chars): ")

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", 5000))
    server.listen(1)
    print("Server waiting...")

    conn, addr = server.accept()
    print("Connected:", addr)

    ciphertext = conn.recv(2048)

    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext), AES.block_size)

    print("Encrypted received:", ciphertext.hex())
    print("Decrypted:", plaintext.decode())

    conn.close()

if __name__ == "__main__":
    main()
