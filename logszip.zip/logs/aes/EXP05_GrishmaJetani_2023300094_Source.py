import secrets, random, time
from cryptography.hazmat.primitives import padding as sympadding

def xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))

def int_to_bytes(n: int, length: int) -> bytes:
    return n.to_bytes(length, 'big')

def bytes_to_int(b: bytes) -> int:
    return int.from_bytes(b, 'big')

# AES Implementation
# AES S-box and inverse S-box initialization
SBOX = [
0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
]
INV_SBOX = [0]*256
for i,v in enumerate(SBOX): INV_SBOX[v]=i
# Round constants for key expansion
RCON = [0x00,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1B,0x36]

def sub_word(w: bytes) -> bytes: return bytes(SBOX[b] for b in w)
def rot_word(w: bytes) -> bytes: return w[1:]+w[:1]

# Expand 128-bit AES key into round keys
def key_expansion(key16: bytes):
    Nk = 4; Nr = 10
    w = [ key16[i:i+4] for i in range(0,16,4) ]
    i = Nk
    while len(w) < 4*(Nr+1):
        temp = w[-1]
        if i % Nk == 0:
            temp = bytes(a ^ b for a,b in zip(sub_word(rot_word(temp)), bytes([RCON[i//Nk],0,0,0])))
        neww = bytes(a ^ b for a,b in zip(w[-Nk], temp))
        w.append(neww)
        i += 1
    return [ b''.join(w[4*i:4*i+4]) for i in range(Nr+1) ]

def gf_mul(a: int, b: int) -> int:
    res = 0
    for _ in range(8):
        if b & 1: res ^= a
        hi = a & 0x80
        a = (a << 1) & 0xFF
        if hi: a ^= 0x1B
        b >>= 1
    return res

# Core AES transformations
def add_round_key(state: bytes, rk: bytes) -> bytes:
    return bytes(s ^ r for s,r in zip(state, rk))
def sub_bytes(state: bytes) -> bytes: return bytes(SBOX[b] for b in state)
def inv_sub_bytes(state: bytes) -> bytes: return bytes(INV_SBOX[b] for b in state)

# ShiftRows and Inverse
def shift_rows(state: bytes) -> bytes:
    s = list(state)
    m = [[ s[r + 4*c] for c in range(4)] for r in range(4)]
    for r in range(1,4): m[r] = m[r][r:]+m[r][:r]
    out = bytearray(16)
    for r in range(4):
        for c in range(4): out[r + 4*c] = m[r][c]
    return bytes(out)

def inv_shift_rows(state: bytes) -> bytes:
    s = list(state)
    m = [[ s[r + 4*c] for c in range(4)] for r in range(4)]
    for r in range(1,4): k=r; m[r]=m[r][-k:]+m[r][:-k]
    out = bytearray(16)
    for r in range(4):
        for c in range(4): out[r + 4*c]=m[r][c]
    return bytes(out)


# MixColumns and Inverse
def mix_columns(state: bytes) -> bytes:
    s = list(state); out=[0]*16
    for c in range(4):
        col = s[4*c:4*c+4]
        out[4*c+0] = (gf_mul(2,col[0]) ^ gf_mul(3,col[1]) ^ col[2] ^ col[3]) & 0xFF
        out[4*c+1] = (col[0] ^ gf_mul(2,col[1]) ^ gf_mul(3,col[2]) ^ col[3]) & 0xFF
        out[4*c+2] = (col[0] ^ col[1] ^ gf_mul(2,col[2]) ^ gf_mul(3,col[3])) & 0xFF
        out[4*c+3] = (gf_mul(3,col[0]) ^ col[1] ^ col[2] ^ gf_mul(2,col[3])) & 0xFF
    return bytes(out)

def inv_mix_columns(state: bytes) -> bytes:
    s = list(state); out=[0]*16
    for c in range(4):
        col = s[4*c:4*c+4]
        out[4*c+0] = (gf_mul(0x0e,col[0]) ^ gf_mul(0x0b,col[1]) ^ gf_mul(0x0d,col[2]) ^ gf_mul(0x09,col[3])) & 0xFF
        out[4*c+1] = (gf_mul(0x09,col[0]) ^ gf_mul(0x0e,col[1]) ^ gf_mul(0x0b,col[2]) ^ gf_mul(0x0d,col[3])) & 0xFF
        out[4*c+2] = (gf_mul(0x0d,col[0]) ^ gf_mul(0x09,col[1]) ^ gf_mul(0x0e,col[2]) ^ gf_mul(0x0b,col[3])) & 0xFF
        out[4*c+3] = (gf_mul(0x0b,col[0]) ^ gf_mul(0x0d,col[1]) ^ gf_mul(0x09,col[2]) ^ gf_mul(0x0e,col[3])) & 0xFF
    return bytes(out)

# AES block encryption
def aes_encrypt_block(plaintext16: bytes, round_keys) -> bytes:
    state = add_round_key(plaintext16, round_keys[0])
    for r in range(1,10):
        state = sub_bytes(state)
        state = shift_rows(state)
        state = mix_columns(state)
        state = add_round_key(state, round_keys[r])
    state = sub_bytes(state)
    state = shift_rows(state)
    state = add_round_key(state, round_keys[10])
    return state

# AES block decryption
def aes_decrypt_block(cipher16: bytes, round_keys) -> bytes:
    state = add_round_key(cipher16, round_keys[10])
    for r in range(9,0,-1):
        state = inv_shift_rows(state)
        state = inv_sub_bytes(state)
        state = add_round_key(state, round_keys[r])
        state = inv_mix_columns(state)
    state = inv_shift_rows(state)
    state = inv_sub_bytes(state)
    state = add_round_key(state, round_keys[0])
    return state

def pkcs7_pad_msg(msg: bytes) -> bytes:
    padder = sympadding.PKCS7(128).padder()
    return padder.update(msg) + padder.finalize()

def pkcs7_unpad_msg(msg: bytes) -> bytes:
    unpadder = sympadding.PKCS7(128).unpadder()
    return unpadder.update(msg) + unpadder.finalize()

# ECB and CBC modes
def aes_encrypt_ecb(plaintext: bytes, key16: bytes) -> bytes:
    padded = pkcs7_pad_msg(plaintext)
    round_keys = key_expansion(key16)
    cipher = b''.join([aes_encrypt_block(padded[i:i+16], round_keys) for i in range(0,len(padded),16)])
    return cipher

def aes_decrypt_ecb(ciphertext: bytes, key16: bytes) -> bytes:
    round_keys = key_expansion(key16)
    decrypted = b''.join([aes_decrypt_block(ciphertext[i:i+16], round_keys) for i in range(0,len(ciphertext),16)])
    return pkcs7_unpad_msg(decrypted)

def aes_encrypt_cbc(plaintext: bytes, key16: bytes, iv: bytes) -> bytes:
    padded = pkcs7_pad_msg(plaintext)
    round_keys = key_expansion(key16)
    prev = iv
    cipher = b''
    for i in range(0,len(padded),16):
        block = xor_bytes(padded[i:i+16], prev)
        encrypted = aes_encrypt_block(block, round_keys)
        cipher += encrypted
        prev = encrypted
    return cipher

def aes_decrypt_cbc(ciphertext: bytes, key16: bytes, iv: bytes) -> bytes:
    round_keys = key_expansion(key16)
    prev = iv
    decrypted = b''
    for i in range(0,len(ciphertext),16):
        block = aes_decrypt_block(ciphertext[i:i+16], round_keys)
        decrypted += xor_bytes(block, prev)
        prev = ciphertext[i:i+16]
    return pkcs7_unpad_msg(decrypted)

# RSA Implementation
def is_prime(n, k=5):
    if n<2: return False
    if n==2 or n==3: return True
    if n%2==0: return False
    r,s = 0,n-1
    while s%2==0: r+=1; s//=2
    for _ in range(k):
        a = random.randrange(2,n-1)
        x = pow(a,s,n)
        if x==1 or x==n-1: continue
        for _ in range(r-1):
            x = pow(x,2,n)
            if x==n-1: break
        else: return False
    return True

def generate_prime(bits=16):
    while True:
        p = random.getrandbits(bits) | 1
        if is_prime(p): return p

# Generate RSA key pair
def rsa_keygen(bits=16):
    p = generate_prime(bits)
    q = generate_prime(bits)
    n = p*q
    phi = (p-1)*(q-1)
    e = 65537
    d = pow(e,-1,phi)
    return (e,n),(d,n)

# RSA encryption/decryption 
def rsa_encrypt(m_int: int, pubkey):
    e,n = pubkey
    return pow(m_int,e,n)

def rsa_decrypt(c_int: int, privkey):
    d,n = privkey
    return pow(c_int,d,n)

def pkcs1_pad(msg: bytes, size: int) -> bytes:
    if len(msg) > size-11: raise ValueError("Message too long")
    padding = b''
    while len(padding) < size - len(msg) -3:
        b = secrets.token_bytes(1)
        if b!=b'\x00': padding += b
    return b'\x00\x02'+padding+b'\x00'+msg

def pkcs1_unpad(padded: bytes) -> bytes:
    assert padded[0]==0 and padded[1]==2
    i=2
    while padded[i]!=0: i+=1
    return padded[i+1:]

# Hybrid AES+RSA
# Encrypt message using AES (CBC) + encrypt AES key using RSA
def hybrid_encrypt(message: bytes, rsa_pubkey) -> tuple:
    session_key = secrets.token_bytes(16)
    encrypted_key_int = rsa_encrypt(bytes_to_int(pkcs1_pad(session_key, 32)), rsa_pubkey)
    iv = secrets.token_bytes(16)
    encrypted_message = aes_encrypt_cbc(message, session_key, iv)
    return encrypted_key_int, encrypted_message, iv, session_key

# Decrypt: RSA → AES key → Decrypt message
def hybrid_decrypt(encrypted_key_int, encrypted_message, iv, rsa_privkey) -> bytes:
    session_key = pkcs1_unpad(int_to_bytes(rsa_decrypt(encrypted_key_int, rsa_privkey),32))
    decrypted_message = aes_decrypt_cbc(encrypted_message, session_key, iv)
    return decrypted_message

# -------------------------
# Menu-Driven System
# -------------------------
def main():
    rsa_pub=None; rsa_priv=None
    while True:
        print("\nMenu:")
        print("1) AES Encryption/Decryption")
        print("2) RSA Encryption/Decryption")
        print("3) Hybrid System")
        print("4) Performance Comparison")
        print("5) Quit")
        choice = input("Enter choice: ")
        if choice=='1':
            msg = input("Enter plaintext: ").encode()
            key = secrets.token_bytes(16)
            iv = secrets.token_bytes(16)
            cipher_ecb = aes_encrypt_ecb(msg,key)
            cipher_cbc = aes_encrypt_cbc(msg,key,iv)
            print("AES ECB Cipher:", cipher_ecb.hex())
            print("AES ECB Decrypted:", aes_decrypt_ecb(cipher_ecb,key))
            print("AES CBC Cipher:", cipher_cbc.hex())
            print("AES CBC Decrypted:", aes_decrypt_cbc(cipher_cbc,key,iv))
        elif choice == '2':
            msg = input("Enter plaintext for RSA: ").encode()

            if rsa_pub is None or rsa_priv is None:
                rsa_pub, rsa_priv = rsa_keygen(bits=512)

            max_chunk_size = 53  # 64 - 11 (PKCS#1 padding overhead)
            chunks = [msg[i:i+max_chunk_size] for i in range(0, len(msg), max_chunk_size)]

            encrypted_chunks = []
            decrypted_chunks = []

            for chunk in chunks:
                padded = pkcs1_pad(chunk, 64)
                cipher_int = rsa_encrypt(bytes_to_int(padded), rsa_pub)
                encrypted_chunks.append(cipher_int)

            for cipher_int in encrypted_chunks:
                decrypted_padded = int_to_bytes(rsa_decrypt(cipher_int, rsa_priv), 64)
                decrypted_chunk = pkcs1_unpad(decrypted_padded)
                decrypted_chunks.append(decrypted_chunk)

            full_cipher = encrypted_chunks
            full_plain = b''.join(decrypted_chunks)

            print("RSA Cipher (list of integers):", full_cipher)
            print("RSA Decrypted:", full_plain.decode(errors='ignore'))
        elif choice=='3':
            msg = input("Enter plaintext: ").encode()
            # Ensure RSA keys are of adequate size (≥ 512 bits)
            if rsa_pub is None or rsa_priv is None or rsa_pub[1].bit_length() < 512:
                rsa_pub, rsa_priv = rsa_keygen(bits=512)
            else:
                print(f"Using existing RSA keys (modulus size: {rsa_pub[1].bit_length()} bits)")
            encrypted_key_int, encrypted_message, iv, session_key = hybrid_encrypt(msg, rsa_pub)
            decrypted_msg = hybrid_decrypt(encrypted_key_int, encrypted_message, iv, rsa_priv)
            print("Hybrid AES+RSA Encrypted Message:", encrypted_message.hex())
            print("Hybrid AES+RSA Decrypted Message:", decrypted_msg.decode())
        elif choice == '4':
            msg = input("Enter plaintext: ").encode()
            print("Generating RSA keys (small bits for demo, increase for real)...")
            rsa_pub, rsa_priv = rsa_keygen(bits=512)

            # --- RSA Full Process (with padding & chunking) ---
            max_chunk_size = 53  # 64 - 11 bytes for PKCS#1 v1.5 padding
            rsa_chunks = [msg[i:i+max_chunk_size] for i in range(0, len(msg), max_chunk_size)]
            rsa_encrypted = []
            rsa_decrypted = []

            start = time.time()
            for chunk in rsa_chunks:
                padded = pkcs1_pad(chunk, 64)
                cipher_int = rsa_encrypt(bytes_to_int(padded), rsa_pub)
                rsa_encrypted.append(cipher_int)
            for cipher_int in rsa_encrypted:
                decrypted_padded = int_to_bytes(rsa_decrypt(cipher_int, rsa_priv), 64)
                decrypted_chunk = pkcs1_unpad(decrypted_padded)
                rsa_decrypted.append(decrypted_chunk)
            end = time.time()

            rsa_final_plaintext = b''.join(rsa_decrypted)
            print(f"RSA Time Taken: {end-start:.6f} seconds")
            print("RSA Decrypted:", rsa_final_plaintext.decode(errors='ignore'))

            # --- Hybrid AES + RSA ---
            start = time.time()
            encrypted_key_int, encrypted_message, iv, session_key = hybrid_encrypt(msg, rsa_pub)
            decrypted_msg = hybrid_decrypt(encrypted_key_int, encrypted_message, iv, rsa_priv)
            end = time.time()

            print(f"Hybrid AES+RSA Time Taken: {end-start:.6f} seconds")
            print("Hybrid Decrypted:", decrypted_msg.decode(errors='ignore'))
        elif choice=='5':
            break
        else:
            print("Invalid choice!")

if __name__=="__main__":
    main()


