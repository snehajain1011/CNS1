import socket
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

def get_key(prompt):
    while True:
        key = input(prompt)
        if len(key) in (16, 24, 32):
            return key.encode()
        print("Key must be 16, 24, or 32 characters!")

def get_iv(prompt):
    while True:
        iv = input(prompt)
        if len(iv) == 16:
            return iv.encode()
        print("IV must be exactly 16 characters!")

def main():
    key = get_key("Enter AES key (16/24/32 chars): ")
    iv  = get_iv("Enter IV (16 chars): ")

    msg = input("Enter message: ").encode()

    cipher = AES.new(key, AES.MODE_CBC, iv)
    ciphertext = cipher.encrypt(pad(msg, AES.block_size))

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", 5000))
    client.send(ciphertext)
    client.close()

    print("Encrypted sent:", ciphertext.hex())

if __name__ == "__main__":
    main()
