# ---------------- ELLIPTIC CURVE PARAMETERS ----------------
p = 97       # prime
a = 2
b = 3
G = (3, 6)   # base point


# ---------------- BASIC ECC FUNCTIONS ----------------
def inverse_mod(k, p):
    """Compute modular inverse."""
    return pow(k, p - 2, p)


def point_add(P, Q):
    """Add two points P + Q on the curve."""
    if P is None:
        return Q
    if Q is None:
        return P

    if P[0] == Q[0] and (P[1] != Q[1] or P[1] == 0):
        return None

    if P != Q:
        m = (Q[1] - P[1]) * inverse_mod(Q[0] - P[0], p) % p
    else:
        m = (3 * P[0]**2 + a) * inverse_mod(2 * P[1], p) % p

    x = (m*m - P[0] - Q[0]) % p
    y = (m*(P[0] - x) - P[1]) % p
    return (x, y)


def scalar_mult(k, P):
    """Compute k * P."""
    result = None
    addend = P

    while k:
        if k & 1:
            result = point_add(result, addend)
        addend = point_add(addend, addend)
        k >>= 1

    return result


# ---------------- ECC ENCRYPTION ----------------
def ecc_encrypt(M, pub_key):
    # Represent message as a point (simple method)
    M_point = (M % p, (M * M) % p)

    k = 7  # random session key, fixed for demo
    C1 = scalar_mult(k, G)
    C2 = point_add(M_point, scalar_mult(k, pub_key))
    return C1, C2


# ---------------- ECC DECRYPTION ----------------
def ecc_decrypt(C1, C2, priv_key):
    S = scalar_mult(priv_key, C1)
    S_inv = (S[0], (-S[1]) % p)
    M_point = point_add(C2, S_inv)
    return M_point


# ------------------- MAIN PROGRAM -------------------
def main():
    print("\n--- Simple ECC Demo ---")

    # Key generation
    priv = int(input("Enter private key: "))
    pub = scalar_mult(priv, G)
    print("Public key:", pub)

    # Message input
    msg = int(input("Enter numeric message (<= 50): "))

    # Encrypt
    C1, C2 = ecc_encrypt(msg, pub)
    print("\nCiphertext:")
    print("C1 =", C1)
    print("C2 =", C2)

    # Decrypt
    dec_point = ecc_decrypt(C1, C2, priv)
    print("\nDecrypted Point:", dec_point)
    print("Recovered Message:", dec_point[0])


# Run
if __name__ == "__main__":
    main()
