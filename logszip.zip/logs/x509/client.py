import socket
import base64
import os
from time import sleep
from datetime import datetime, timezone
from cryptography import x509
from cryptography.x509.oid import NameOID, ExtensionOID
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.x509 import ocsp

# CONFIG 
SERVER_ADDR = ("127.0.0.1", 6001)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(SERVER_ADDR)

# Globals for username-aware file handling
username = None
USER_DIR = None

def user_path(filename: str):
    """Returns path inside the user's folder."""
    return os.path.join(USER_DIR, filename)


# COMMUNICATION 
def send_cmd(cmd):
    client.sendall(cmd.encode())
    sleep(0.15)
    try:
        data = client.recv(65536).decode().strip()
        return data
    except:
        return ""


# KEY MANAGEMENT 
def load_or_generate_key():
    key_path = user_path("client_key.pem")
    if os.path.exists(key_path):
        with open(key_path, "rb") as f:
            priv = serialization.load_pem_private_key(f.read(), password=None)
    else:
        priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        with open(key_path, "wb") as f:
            f.write(priv.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        print(f"[CLIENT] Generated new private key at {key_path}")
    return priv


# REGISTRATION 
def register_username(username):
    nums = PUB_KEY.public_numbers()
    e = nums.e
    n = nums.n
    resp = send_cmd(f"REGISTER {username} {e} {n}")
    print("Server:", resp)


# CSR + CERTIFICATE 
def create_csr(username, san_list=None):
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, username)])
    csr_builder = x509.CertificateSigningRequestBuilder().subject_name(name)
    if san_list:
        san = x509.SubjectAlternativeName([x509.DNSName(v) for v in san_list])
        csr_builder = csr_builder.add_extension(san, critical=False)
    csr = csr_builder.sign(PRIV_KEY, hashes.SHA256())
    return csr.public_bytes(serialization.Encoding.PEM)


def submit_csr_and_get_cert(username):
    csr_pem = create_csr(username)
    b64 = base64.b64encode(csr_pem).decode()
    resp = send_cmd(f"SUBMIT_CSR {username} {b64}")
    if resp.startswith("ISSUED"):
        toks = resp.split(maxsplit=2)
        if len(toks) >= 3:
            b64pem = toks[2]
            cert_pem = base64.b64decode(b64pem.encode())
            cert_path = user_path("client_cert.pem")
            with open(cert_path, "wb") as f:
                f.write(cert_pem)
            print(f"[CLIENT] Received issued certificate for {username} -> {cert_path}")
            return True
    print("[CLIENT] Failed to get certificate:", resp)
    return False


# ROOT & CRL 
def fetch_root_cert():
    resp = send_cmd("GET_ROOT")
    if resp.startswith("ROOT"):
        pem_b64 = resp.split(maxsplit=1)[1]
        pem = base64.b64decode(pem_b64.encode())
        root_path = user_path("root_cert.pem")
        with open(root_path, "wb") as f:
            f.write(pem)
        print("[CLIENT] Saved root certificate to", root_path)
        return True
    print("[CLIENT] GET_ROOT failed:", resp)
    return False


# PARSING 
def parse_certificate_file(path):
    with open(path, "rb") as f:
        data = f.read()
    cert = x509.load_pem_x509_certificate(data)
    print("Subject:", cert.subject.rfc4514_string())
    print("Issuer:", cert.issuer.rfc4514_string())
    print("Serial:", cert.serial_number)
    print("Not Before:", cert.not_valid_before)
    print("Not After :", cert.not_valid_after)
    print("Signature Algorithm:", cert.signature_hash_algorithm.name)
    try:
        ext = cert.extensions.get_extension_for_oid(ExtensionOID.BASIC_CONSTRAINTS)
        print("Basic Constraints:", ext.value)
    except Exception:
        pass
    try:
        ku = cert.extensions.get_extension_for_oid(ExtensionOID.KEY_USAGE)
        print("Key Usage:", ku.value)
    except Exception:
        pass
    try:
        san = cert.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
        print("SAN:", san.value)
    except Exception:
        pass
    print("SHA256 Fingerprint:", cert.fingerprint(hashes.SHA256()).hex())


# VERIFICATION 
def verify_cert_signature(cert, issuer_cert):
    pub = issuer_cert.public_key()
    try:
        pub.verify(
            signature=cert.signature,
            data=cert.tbs_certificate_bytes,
            padding=padding.PKCS1v15(),
            algorithm=cert.signature_hash_algorithm,
        )
        return True
    except Exception as e:
        print("Signature verification failed:", e)
        return False


def verify_chain(cert_path, root_path, check_crl=True):
    with open(cert_path, "rb") as f:
        cert = x509.load_pem_x509_certificate(f.read())
    with open(root_path, "rb") as f:
        root = x509.load_pem_x509_certificate(f.read())

    ok = verify_cert_signature(cert, root)
    if not ok:
        print("Chain verification: SIGNATURE FAILED")
        return False

    now = datetime.now(timezone.utc)
    nb = cert.not_valid_before.replace(tzinfo=timezone.utc)
    na = cert.not_valid_after.replace(tzinfo=timezone.utc)

    if nb > now or na < now:
        print("Chain verification: Certificate validity period check failed")
        return False

    if check_crl:
        resp = send_cmd("GET_CRL")
        if resp.startswith("CRL"):
            b64p = resp.split(maxsplit=1)[1]
            crl_pem = base64.b64decode(b64p.encode())
            crl_path = user_path("server_crl.pem")
            with open(crl_path, "wb") as f:
                f.write(crl_pem)
            crl = x509.load_pem_x509_crl(crl_pem)
            for revoked in crl:
                if revoked.serial_number == cert.serial_number:
                    print(f"Chain verification: Certificate serial {cert.serial_number} is revoked")
                    return False
        else:
            print("Warning: Could not fetch CRL from server:", resp)
    print("Chain verification: OK")
    return True


# OCSP 
def request_ocsp(serial_int):
    resp = send_cmd(f"OCSP_REQUEST {serial_int}")
    if resp.startswith("OCSP_RESP"):
        b64 = resp.split(maxsplit=1)[1]
        der = base64.b64decode(b64.encode())
        path = user_path("ocsp_response.der")
        with open(path, "wb") as f:
            f.write(der)
        print(f"Saved OCSP response DER to {path}")
        return der
    else:
        print("OCSP request failed:", resp)
        return None


def verify_ocsp_response(der_bytes, cert_path, issuer_path):
    ocsp_resp = ocsp.load_der_ocsp_response(der_bytes)
    if ocsp_resp.response_status.name != "SUCCESSFUL":
        print("OCSP responder returned status:", ocsp_resp.response_status)
        return False

    with open(issuer_path, "rb") as f:
        issuer = x509.load_pem_x509_certificate(f.read())

    try:
        issuer.public_key().verify(
            ocsp_resp.signature,
            ocsp_resp.tbs_response_bytes,
            padding.PKCS1v15(),
            ocsp_resp.signature_hash_algorithm,
        )
    except Exception as e:
        print("OCSP signature verification failed:", e)
        return False

    single = next(iter(ocsp_resp.responses))
    status = getattr(single, "certificate_status", None)
    serial = getattr(single, "serial_number", None)

    if status is None:
        print("OCSP: Could not read certificate status from response")
        return False

    if status.name == "GOOD":
        print(f"OCSP: Certificate {serial} status = GOOD")
        return True
    elif status.name == "REVOKED":
        rev_time = getattr(single, "revocation_time", "Unknown")
        print(f"OCSP: Certificate {serial} status = REVOKED (revocation_time={rev_time})")
        return False
    else:
        print(f"OCSP: Certificate {serial} status = UNKNOWN")
        return False


# REVOKE
def request_revoke(serial, reason="unspecified"):
    resp = send_cmd(f"REVOKE {serial} {reason}")
    print("Server:", resp)

def menu_loop(username):
    while True:
        print("\nMenu:")
        print("1) Request a signed certificate from CA (SUBMIT CSR)")
        print("2) Fetch root certificate from server")
        print("3) Parse local certificate")
        print("4) Verify certificate chain")
        print("5) Get CRL from server")
        print("6) Request OCSP status for serial")
        print("7) Revoke cert serial")
        print("8) Quit")

        choice = input("Enter choice: ").strip()
        cert_path = user_path("client_cert.pem")
        root_path = user_path("root_cert.pem")

        if choice == "1":
            ok = submit_csr_and_get_cert(username)
            if ok:
                print("Certificate saved to", cert_path)
        elif choice == "2":
            fetch_root_cert()
        elif choice == "3":
            if os.path.exists(cert_path):
                parse_certificate_file(cert_path)
            else:
                print("No certificate found. Issue one first.")
        elif choice == "4":
            if not os.path.exists(cert_path):
                print("No client cert.")
                continue
            if not os.path.exists(root_path):
                print("No root cert. Fetching...")
                fetch_root_cert()
            verify_chain(cert_path, root_path)
        elif choice == "5":
            resp = send_cmd("GET_CRL")
            if resp.startswith("CRL"):
                pem = base64.b64decode(resp.split(maxsplit=1)[1].encode())
                crl_path = user_path("server_crl.pem")
                with open(crl_path, "wb") as f:
                    f.write(pem)
                print("Saved CRL to", crl_path)
        elif choice == "6":
            s = input("Enter serial to check via OCSP: ").strip()
            try:
                serial = int(s)
            except:
                print("Bad serial")
                continue
            der = request_ocsp(serial)
            if der:
                if not os.path.exists(root_path):
                    print("No root cert locally, fetching...")
                    fetch_root_cert()
                verify_ocsp_response(der, cert_path if os.path.exists(cert_path) else None, root_path)
        elif choice == "7":
            s = input("Enter serial to revoke: ").strip()
            r = input("Reason (optional): ").strip() or "unspecified"
            request_revoke(s, r)
        elif choice == "8":
            print("Quitting.")
            client.close()
            break
        else:
            print("Unknown option.")


if __name__ == "__main__":
    username = input("Enter username to register: ").strip()
    USER_DIR = username
    os.makedirs(USER_DIR, exist_ok=True)

    PRIV_KEY = load_or_generate_key()
    PUB_KEY = PRIV_KEY.public_key()

    register_username(username)
    menu_loop(username)
