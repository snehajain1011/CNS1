
import socket
import threading
import base64
import json
from datetime import datetime, timedelta
from time import sleep
from datetime import timezone

from cryptography import x509
from cryptography.x509.oid import NameOID, ExtensionOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes
from cryptography.x509 import ocsp

HOST = "127.0.0.1"
PORT = 6001

clients = {}
public_keys = {}
issued_certs = {}
serial_db = {}
revoked_serials = {} 

# Create Root CA
def generate_root_ca():
    key = rsa.generate_private_key(public_exponent=65537, key_size=4096)
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"IN"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"MiniLab Root CA"),
        x509.NameAttribute(NameOID.COMMON_NAME, u"MiniLab Root CA"),
    ])
    now = datetime.now(timezone.utc)

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=1))
        .not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.BasicConstraints(ca=True, path_length=1), critical=True)
        .sign(key, hashes.SHA256())
    )
    return key, cert

CA_KEY, CA_CERT = generate_root_ca()
CA_SERIAL_COUNTER = 1000

def pem_b64(pem_bytes):
    return base64.b64encode(pem_bytes).decode()

def b64_to_pem(b64str):
    return base64.b64decode(b64str.encode())

def sign_csr_and_issue(csr_pem_bytes, subject_cn):
    global CA_SERIAL_COUNTER
    csr = x509.load_pem_x509_csr(csr_pem_bytes)
    now = datetime.now(timezone.utc)

    serial = CA_SERIAL_COUNTER
    CA_SERIAL_COUNTER += 1

    cert_builder = x509.CertificateBuilder()\
        .subject_name(csr.subject)\
        .issuer_name(CA_CERT.subject)\
        .public_key(csr.public_key())\
        .serial_number(serial)\
        .not_valid_before(now - timedelta(minutes=1))\
        .not_valid_after(now + timedelta(minutes=30))\
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)\
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(csr.public_key()), critical=False)\
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(CA_KEY.public_key()), critical=False)

    # Copy SAN if present in CSR
    try:
        ext = csr.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME)
        cert_builder = cert_builder.add_extension(ext.value, critical=False)
    except Exception:
        pass

    cert = cert_builder.sign(private_key=CA_KEY, algorithm=hashes.SHA256())
    return cert

def build_crl():
    builder = x509.CertificateRevocationListBuilder()
    builder = builder.issuer_name(CA_CERT.subject)
    now = datetime.now(timezone.utc)

    builder = builder.last_update(now)
    builder = builder.next_update(now + timedelta(days=7))
    for serial, info in revoked_serials.items():
        revoked = x509.RevokedCertificateBuilder()\
            .serial_number(serial)\
            .revocation_date(info['revoked_at'])\
            .build()
        builder = builder.add_revoked_certificate(revoked)
    crl = builder.sign(private_key=CA_KEY, algorithm=hashes.SHA256())
    return crl

def build_ocsp_response(serial_int):
    """
    Build a basic OCSP response for 'serial_int'.
    Status = REVOKED if in revoked_serials, else GOOD if issued, else UNKNOWN.
    Response is DER-encoded OCSPResponse bytes.
    """
    responder_key = CA_KEY
    responder_cert = CA_CERT

    issuer = CA_CERT
    cert = None
    if serial_int in serial_db:
        cert = issued_certs.get(serial_db[serial_int])

    builder = ocsp.OCSPResponseBuilder()

    # Determine cert status
    if cert is None:
        # Unknown serial
        builder = builder.add_response(
            cert=CA_CERT,
            issuer=issuer,
            algorithm=hashes.SHA1(),
            cert_status=ocsp.OCSPCertStatus.UNKNOWN,
            this_update=datetime.now(timezone.utc),
            next_update=datetime.now(timezone.utc) + timedelta(days=1),
            revocation_time=None,
            revocation_reason=None
        )
    elif serial_int in revoked_serials:
        revinfo = revoked_serials[serial_int]
        builder = builder.add_response(
            cert=cert,
            issuer=issuer,
            algorithm=hashes.SHA1(),
            cert_status=ocsp.OCSPCertStatus.REVOKED,
            this_update=datetime.now(timezone.utc),
            next_update=datetime.now(timezone.utc) + timedelta(days=1),
            revocation_time=revinfo['revoked_at'],
            revocation_reason=x509.ReasonFlags.unspecified
        )
    else:
        builder = builder.add_response(
            cert=cert,
            issuer=issuer,
            algorithm=hashes.SHA1(),
            cert_status=ocsp.OCSPCertStatus.GOOD,
            this_update=datetime.now(timezone.utc),
            next_update=datetime.now(timezone.utc) + timedelta(days=1),
            revocation_time=None,
            revocation_reason=None
        )

    ocsp_resp = builder.responder_id(
        ocsp.OCSPResponderEncoding.HASH,
        responder_cert
    ).certificates([responder_cert]).sign(
        private_key=responder_key,
        algorithm=hashes.SHA256()
    )

    der = ocsp_resp.public_bytes(serialization.Encoding.DER)
    return der


def handle_client(conn, addr):
    name = None
    try:
        while True:
            raw = conn.recv(65536)
            if not raw:
                break
            msg = raw.decode()
            parts = msg.strip().split(maxsplit=1)
            if not parts:
                continue
            cmd = parts[0].upper()
            rest = parts[1] if len(parts) > 1 else ""

            if cmd == "REGISTER":
                toks = rest.split()
                if len(toks) < 3:
                    conn.send(b"ERROR Malformed REGISTER\n")
                    continue
                name = toks[0]
                e_str, n_str = toks[1], toks[2]
                public_keys[name] = (int(e_str), int(n_str))
                clients[name] = conn
                conn.send(f"[SERVER] Registered as {name}\n".encode())
                print(f"[SERVER] {name} registered")

            elif cmd == "GET":
                target = rest.strip()
                if target in public_keys:
                    e, n = public_keys[target]
                    conn.send(f"PUBKEY {target} {e} {n}\n".encode())
                else:
                    conn.send(f"ERROR No such user {target}\n".encode())

            elif cmd == "SUBMIT_CSR":
                toks = rest.split(maxsplit=1)
                if len(toks) != 2:
                    conn.send(b"ERROR Malformed SUBMIT_CSR\n")
                    continue
                username, b64csr = toks
                try:
                    csr_pem = b64_to_pem(b64csr)
                    cert = sign_csr_and_issue(csr_pem, username)
                    issued_certs[username] = cert
                    serial_db[cert.serial_number] = username
                    cert_pem = cert.public_bytes(serialization.Encoding.PEM)
                    conn.send(f"ISSUED {username} {pem_b64(cert_pem)}\n".encode())
                    print(f"[CA] Issued cert for {username} serial={cert.serial_number}")
                except Exception as e:
                    conn.send(f"ERROR CSR signing failed: {e}\n".encode())

            elif cmd == "GET_CERT":
                user = rest.strip()
                if user in issued_certs:
                    pem = issued_certs[user].public_bytes(serialization.Encoding.PEM)
                    conn.send(f"CERT {user} {pem_b64(pem)}\n".encode())
                else:
                    conn.send(f"ERROR No cert for {user}\n".encode())

            elif cmd == "GET_ROOT":
                pem = CA_CERT.public_bytes(serialization.Encoding.PEM)
                conn.send(f"ROOT {pem_b64(pem)}\n".encode())

            elif cmd == "REVOKE":
                toks = rest.split(maxsplit=1)
                if len(toks) < 1:
                    conn.send(b"ERROR Malformed REVOKE\n")
                    continue
                try:
                    serial = int(toks[0])
                    reason = toks[1] if len(toks) > 1 else "unspecified"
                    revoked_serials[serial] = {'revoked_at': datetime.now(timezone.utc), 'reason': reason}
                    conn.send(f"REVOKED {serial}\n".encode())
                    print(f"[CA] Revoked serial {serial}")
                except Exception as e:
                    conn.send(f"ERROR REVOKE failed: {e}\n".encode())

            elif cmd == "GET_CRL":
                crl = build_crl()
                pem = crl.public_bytes(serialization.Encoding.PEM)
                conn.send(f"CRL {pem_b64(pem)}\n".encode())

            elif cmd == "OCSP_REQUEST":
                # OCSP_REQUEST <serial>
                s = rest.strip()
                try:
                    serial = int(s)
                except:
                    conn.send(b"ERROR Bad serial\n")
                    continue
                der = build_ocsp_response(serial)
                b64 = base64.b64encode(der).decode()
                conn.send(f"OCSP_RESP {b64}\n".encode())

            elif cmd == "SET_KEY":
                toks = rest.split(maxsplit=1)
                if len(toks) < 2:
                    conn.send(b"ERROR Malformed SET_KEY\n")
                    continue
                target = toks[0]
                rsa_cipher = toks[1]
                if target in clients:
                    try:
                        clients[target].sendall(f"SET_KEY {name} {rsa_cipher}\n".encode())
                    except Exception:
                        conn.send(f"ERROR Could not deliver key to {target}\n".encode())
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            elif cmd == "SEND":
                toks = rest.split(maxsplit=1)
                if len(toks) < 2:
                    conn.send(b"ERROR Malformed SEND\n")
                    continue
                target = toks[0]
                ciphertext = toks[1]
                if target in clients:
                    try:
                        clients[target].sendall(f"FROM {name} {ciphertext}\n".encode())
                    except:
                        conn.send(f"ERROR Could not deliver to {target}\n".encode())
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            else:
                conn.send(b"ERROR Unknown command\n")
    except Exception as e:
        print("[SERVER] handler error:", e)
    finally:
        if name and name in clients:
            clients.pop(name, None)
        try:
            conn.close()
        except:
            pass

def start_server():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((HOST, PORT))
    s.listen(10)
    print(f"[SERVER] Listening on {HOST}:{PORT}")
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    print("[CA] Root CA created. Subject:", CA_CERT.subject.rfc4514_string())
    start_server()
