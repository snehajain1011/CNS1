def basic_euclidean(a, b):
    print("\nBasic Euclidean Algorithm (GCD)")
    print("{:<10} {:<10} {:<10} {:<10}".format("q", "r1", "r2", "r"))
    
    r1, r2 = a, b
    while r2 != 0:
        q = r1 // r2
        r = r1 % r2
        print("{:<10} {:<10} {:<10} {:<10}".format(q, r1, r2, r))
        r1, r2 = r2, r

    print(f"\nGCD({a}, {b}) = {r1}")
    return r1

def extended_euclidean(a, b):
    print("\nExtended Euclidean Algorithm (GCD and s, t)")
    print("{:<5} {:<10} {:<10} {:<10} {:<6} {:<6} {:<6} {:<6} {:<6} {:<6}".format(
        "q", "r1", "r2", "r", "s1", "s2", "s", "t1", "t2", "t"))

    r1, r2 = a, b
    s1, s2 = 1, 0
    t1, t2 = 0, 1

    while r2 != 0:
        q = r1 // r2
        r = r1 % r2
        s = s1 - q * s2
        t = t1 - q * t2

        print("{:<5} {:<10} {:<10} {:<10} {:<6} {:<6} {:<6} {:<6} {:<6} {:<6}".format(
            q, r1, r2, r, s1, s2, s, t1, t2, t))

        r1, r2 = r2, r
        s1, s2 = s2, s
        t1, t2 = t2, t

    print(f"\nGCD({a}, {b}) = {r1}")
    print(f"Coefficients (s, t): ({s1}, {t1}) such that {a}*({s1}) + {b}*({t1}) = {r1}")
    return r1, s1, t1

def multiplicative_inverse(a, m):
    print("\nMultiplicative Inverse using Euclidean Algorithm")
    print("{:<10} {:<10} {:<10} {:<10} {:<10} {:<10} {:<10}".format(
        "q", "r1", "r2", "r", "t1", "t2", "t"))

    r1, r2 = m, a
    t1, t2 = 0, 1

    while r2 != 0:
        q = r1 // r2
        r = r1 % r2
        t = t1 - q * t2

        print("{:<10} {:<10} {:<10} {:<10} {:<10} {:<10} {:<10}".format(
            q, r1, r2, r, t1, t2, t))

        r1, r2 = r2, r
        t1, t2 = t2, t

    if r1 != 1:
        print(f"\nNo Multiplicative Inverse exists for {a} modulo {m} (GCD ≠ 1)")
        return None
    else:
        inverse = t1 % m
        print(f"\nMultiplicative Inverse of {a} modulo {m} is {inverse}")
        return inverse

def main():
    while True:
        print("\n---------------- MENU ----------------")
        print("1. Basic Euclidean Algorithm for GCD")
        print("2. Extended Euclidean Algorithm for GCD and (s,t)")
        print("3. Euclidean Algorithm for Multiplicative Inverse")
        print("4. Exit")
        print("\n")

        choice = input("Enter your choice (1-4): ")

        if choice in ['1', '2', '3']:
            try:
                a = int(input("Enter first number (a): "))
                b = int(input("Enter second number (b): "))

                if a < 0 or b < 0:
                    print("Please enter non-negative integers only.")
                    continue

                if choice == '1':
                    basic_euclidean(a, b)

                elif choice == '2':
                    extended_euclidean(a, b)

                elif choice == '3':
                    multiplicative_inverse(a, b)

            except ValueError:
                print("Invalid input. Please enter valid integers.")

        elif choice == '4':
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    main()

