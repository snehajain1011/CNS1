from math import gcd

# Function to compute modular inverse using Extended Euclidean Algorithm
def mod_inverse(a, m):
    m0, x0, x1 = m, 0, 1
    if m == 1:
        return 0
    while a > 1:
        q = a // m
        a, m = m, a % m
        x0, x1 = x1 - q * x0, x0
    return x1 + m0 if x1 < 0 else x1

# Chinese Remainder Theorem to reconstruct the number
def chinese_remainder_theorem(remainders, moduli):
    M = 1
    for mi in moduli:
        M *= mi
    result = 0
    for ai, mi in zip(remainders, moduli):
        Mi = M // mi
        Mi_inv = mod_inverse(Mi, mi)
        result += ai * Mi * Mi_inv
    return result % M

# Convert number to tuple of remainders
def to_crt_representation(num, moduli):
    return [num % mi for mi in moduli]

# Main Program
def main():
    # Initialize moduli (pairwise coprime)
    moduli = [3, 5, 7, 11, 13, 17]  # Example moduli (you can change as required)
    M = 1
    for mi in moduli:
        M *= mi
   
    print("Chinese Remainder Theorem Calculator")
    print(f"Moduli set: {moduli}, Combined modulus M = {M}")
   
    while True:
        print("\nMenu:")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Quit")
       
        choice = input("Enter your choice: ")
       
        if choice == '5':
            print("Exiting...")
            break
       
        A = int(input("Enter first number A: "))
        B = int(input("Enter second number B: "))
       
        a_tuple = to_crt_representation(A, moduli)
        b_tuple = to_crt_representation(B, moduli)
       
        print(f"A in CRT form: {a_tuple}")
        print(f"B in CRT form: {b_tuple}")
       
        c_tuple = []
        if choice == '1':  # Addition
            c_tuple = [(ai + bi) % mi for ai, bi, mi in zip(a_tuple, b_tuple, moduli)]
        elif choice == '2':  # Subtraction
            c_tuple = [(ai - bi) % mi for ai, bi, mi in zip(a_tuple, b_tuple, moduli)]
        elif choice == '3':  # Multiplication
            c_tuple = [(ai * bi) % mi for ai, bi, mi in zip(a_tuple, b_tuple, moduli)]
        elif choice == '4':  # Division
            c_tuple = []
            for ai, bi, mi in zip(a_tuple, b_tuple, moduli):
                if gcd(bi, mi) != 1:
                    print(f"Division not possible modulo {mi} (no inverse for {bi})")
                    break
                bi_inv = mod_inverse(bi, mi)
                c_tuple.append((ai * bi_inv) % mi)
        else:
            print("Invalid choice!")
            continue
       
        if c_tuple:
            print(f"Result in CRT form: {c_tuple}")
            C = chinese_remainder_theorem(c_tuple, moduli)
            print(f"Final result (mod {M}): {C}")

if __name__ == "__main__":
    main()
