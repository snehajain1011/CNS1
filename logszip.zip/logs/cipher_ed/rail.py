def rail_fence_encrypt(text, rails):
    text = ''.join([c.lower() for c in text if c.isalpha()])
    fence = [[] for _ in range(rails)]

    row, step = 0, 1
    for ch in text:
        fence[row].append(ch)
        if row == 0: 
            step = 1
        elif row == rails - 1:
            step = -1
        row += step

    return ''.join(''.join(r) for r in fence)


def rail_fence_decrypt(cipher, rails):
    length = len(cipher)

    pattern = []
    row, step = 0, 1
    for _ in range(length):
        pattern.append(row)
        if row == 0: step = 1
        elif row == rails - 1: step = -1
        row += step

    rail_lengths = [pattern.count(r) for r in range(rails)]

    idx = 0
    rails_data = []
    for rlen in rail_lengths:
        rails_data.append(list(cipher[idx:idx+rlen]))
        idx += rlen

    result = ""
    rail_pos = [0] * rails
    for r in pattern:
        result += rails_data[r][rail_pos[r]]
        rail_pos[r] += 1

    return result


# ------------------------- USER INPUT -------------------------
print("\n--- Rail Fence Cipher ---")
choice = input("Encrypt(E) / Decrypt(D): ").strip().upper()
rails = int(input("Enter number of rails: "))
text = input("Enter text: ")

if choice == "E":
    print("Ciphertext:", rail_fence_encrypt(text, rails))
else:
    print("Plaintext:", rail_fence_decrypt(text, rails))
