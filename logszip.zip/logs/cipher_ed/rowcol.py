def rowcol_encrypt(text, key):
    text = ''.join([c.lower() for c in text if c.isalpha()])
    cols = len(key)

    while len(text) % cols != 0:
        text += 'x'

    rows = len(text) // cols
    matrix = [list(text[i*cols:(i+1)*cols]) for i in range(rows)]

    ciphertext = ""
    for k in sorted(range(cols), key=lambda x: key[x]):
        for r in range(rows):
            ciphertext += matrix[r][k]

    return ciphertext


def rowcol_decrypt(cipher, key):
    cols = len(key)
    rows = len(cipher) // cols
    matrix = [[''] * cols for _ in range(rows)]

    order = sorted(range(cols), key=lambda x: key[x])

    idx = 0
    for k in order:
        for r in range(rows):
            matrix[r][k] = cipher[idx]
            idx += 1

    plaintext = ""
    for r in range(rows):
        plaintext += ''.join(matrix[r])

    return plaintext


# ------------------------- USER INPUT -------------------------
print("\n--- Row Column Transposition ---")
choice = input("Encrypt(E) / Decrypt(D): ").strip().upper()
key = list(map(int, input("Enter key numbers separated by space: ").split()))
text = input("Enter text: ")

if choice == "E":
    print("Ciphertext:", rowcol_encrypt(text, key))
else:
    print("Plaintext:", rowcol_decrypt(text, key))
