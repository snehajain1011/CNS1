from string import ascii_lowercase
import numpy as np

# ---------------- Caesar ----------------
def caesar_encrypt(p: str, key: int):
    c = ""
    for t in p.lower():
        if t.isalpha():
            c += chr(((ord(t) - 97 + key) % 26) + 97)
        else:
            c += t
    return c

def caesar_decrypt(c: str, key: int):
    return caesar_encrypt(c, -key)


# ---------------- Monoalphabetic ----------------
def monoalphabetic_encrypt(p: str, key):
    c = ""
    for t in p.lower():
        if t.isalpha():
            c += key[ord(t) - 97]
        else:
            c += t
    return c

def monoalphabetic_decrypt(c: str, key):
    rev_map = {v: ascii_lowercase[i] for i, v in enumerate(key)}
    p = ""
    for t in c.lower():
        if t.isalpha():
            p += rev_map[t]
        else:
            p += t
    return p


# ---------------- Playfair ----------------
def playfair_encrypt(p: str, key: str):
    grid = generate_playfair_grid(key)
    pairs = make_playfair_pairs(p)

    c = ""
    for a, b in pairs:
        rowa, cola = find_pos(a, grid)
        rowb, colb = find_pos(b, grid)
        if rowa == rowb:
            c += grid[rowa][(cola + 1) % 5]
            c += grid[rowb][(colb + 1) % 5]
        elif cola == colb:
            c += grid[(rowa + 1) % 5][cola]
            c += grid[(rowb + 1) % 5][colb]
        else:
            c += grid[rowa][colb]
            c += grid[rowb][cola]
    return c

def playfair_decrypt(c: str, key: str):
    grid = generate_playfair_grid(key)
    pairs = [(c[i], c[i+1]) for i in range(0, len(c), 2)]

    p = ""
    for a, b in pairs:
        rowa, cola = find_pos(a, grid)
        rowb, colb = find_pos(b, grid)
        if rowa == rowb:
            p += grid[rowa][(cola - 1) % 5]
            p += grid[rowb][(colb - 1) % 5]
        elif cola == colb:
            p += grid[(rowa - 1) % 5][cola]
            p += grid[(rowb - 1) % 5][colb]
        else:
            p += grid[rowa][colb]
            p += grid[rowb][cola]
    return p

def generate_playfair_grid(key):
    key = key.lower()
    used = set()
    alphabet = []
    for char in key:
        if char.isalpha() and char != 'j' and char not in used:
            alphabet.append(char)
            used.add(char)
    for char in ascii_lowercase:
        if char != 'j' and char not in used:
            alphabet.append(char)
            used.add(char)
    return [alphabet[x:x+5] for x in range(0, 25, 5)]

def make_playfair_pairs(p):
    p = p.lower().replace('j', 'i')
    p = ''.join([c for c in p if c.isalpha()])
    pairs, i = [], 0
    while i < len(p):
        if i == len(p) - 1:
            pairs.append((p[i], 'x'))
            i += 1
        elif p[i] == p[i + 1]:
            pairs.append((p[i], 'x'))
            i += 1
        else:
            pairs.append((p[i], p[i + 1]))
            i += 2
    return pairs

def find_pos(char, grid):
    for row in range(5):
        for col in range(5):
            if grid[row][col] == char:
                return row, col
    return -1, -1


# ---------------- Hill ----------------
def mod_inverse(a, m):
    """Find modular inverse of a under mod m"""
    a = a % m
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

def hill_encrypt(p: str, key):
    p = ''.join([c.lower() for c in p if c.isalpha()])
    n = len(key)
    while len(p) % n != 0:
        p += 'x'

    c = ""
    for i in range(0, len(p), n):
        block = p[i:i + n]
        vec = np.array([ord(ch) - 97 for ch in block])
        new_vec = np.dot(key, vec) % 26
        c += ''.join(chr(val + 97) for val in new_vec)
    return c

def hill_decrypt(c: str, key):
    c = ''.join([ch.lower() for ch in c if ch.isalpha()])
    n = len(key)

    K = np.array(key)
    det = int(round(np.linalg.det(K)))
    det_mod = det % 26
    det_inv = mod_inverse(det_mod, 26)
    if det_inv is None:
        return "Decryption not possible: Key matrix not invertible under mod 26."

    # Adjugate and modular inverse
    K_inv = (det_inv * np.round(det * np.linalg.inv(K)).astype(int)) % 26

    p = ""
    for i in range(0, len(c), n):
        block = c[i:i + n]
        vec = np.array([ord(ch) - 97 for ch in block])
        new_vec = K_inv.dot(vec) % 26
        p += ''.join(chr(int(val) + 97) for val in new_vec)
    return p


# ---------------- Polyalphabetic (Vigenère) ----------------
def polyalphabetic_encrypt(p: str, key: str):
    c = ""
    p = ''.join([c.lower() for c in p if c.isalpha()])
    full_key = (key * (len(p) // len(key) + 1))[:len(p)]
    for i, t in enumerate(p):
        shift = ord(full_key[i]) - 97
        c += chr(((ord(t) - 97 + shift) % 26) + 97)
    return c

def polyalphabetic_decrypt(c: str, key: str):
    p = ""
    c = ''.join([ch.lower() for ch in c if ch.isalpha()])
    full_key = (key * (len(c) // len(key) + 1))[:len(c)]
    for i, t in enumerate(c):
        shift = ord(full_key[i]) - 97
        p += chr(((ord(t) - 97 - shift) % 26) + 97)
    return p


# ---------------- Main Menu ----------------
def main():
    while True:
        print("\nSelect a cipher:")
        print("1. Caesar Cipher")
        print("2. Monoalphabetic Cipher")
        print("3. Playfair Cipher")
        print("4. Hill Cipher")
        print("5. Polyalphabetic Cipher")
        print("6. Exit")
        op = int(input("Enter your choice: "))

        if op == 6:
            print("Exiting.")
            break

        mode = input("Encrypt or Decrypt (e/d): ").lower()
        text = input("Enter text: ")

        if op == 1:
            key = int(input("Enter key: "))
            if mode == 'e':
                print("Ciphertext:", caesar_encrypt(text, key))
            else:
                print("Plaintext:", caesar_decrypt(text, key))

        elif op == 2:
            cipher = list(input("Enter key (26-letter mapping): "))
            if mode == 'e':
                print("Ciphertext:", monoalphabetic_encrypt(text, cipher))
            else:
                print("Plaintext:", monoalphabetic_decrypt(text, cipher))

        elif op == 3:
            key = input("Enter key string: ")
            if mode == 'e':
                print("Ciphertext:", playfair_encrypt(text, key))
            else:
                print("Plaintext:", playfair_decrypt(text, key))

        elif op == 4:
            n = int(input("Enter size of key matrix: "))
            key_matrix = []
            for _ in range(n):
                row = list(map(int, input().split()))
                key_matrix.append(row)
            if mode == 'e':
                print("Ciphertext:", hill_encrypt(text, key_matrix))
            else:
                print("Plaintext:", hill_decrypt(text, key_matrix))

        elif op == 5:
            key = input("Enter keyword: ")
            if mode == 'e':
                print("Ciphertext:", polyalphabetic_encrypt(text, key))
            else:
                print("Plaintext:", polyalphabetic_decrypt(text, key))

        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
