import struct
import time
import random

# PART A: SHA-256 implementation

# Round constants (first 32 bits of cube roots of the first 64 primes)
K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
    0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
    0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
    0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
    0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
    0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]

# Initial hash values (first 32-bits of sqrt of first 8 primes)
H_INIT = [
    0x6a09e667, 0xbb67ae85,
    0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c,
    0x1f83d9ab, 0x5be0cd19
]

def rightrotate(x, n):
    return ((x >> n) | (x << (32 - n))) & 0xffffffff

def sha256_padding(message_bytes):
    """
    Message preprocessing & padding:
    Append 0x80, then 0x00 bytes until length ≡ 448 (mod 512),
    then append 64-bit big-endian length.
    """
    length_bits = len(message_bytes) * 8
    m = bytearray(message_bytes)
    m.append(0x80)
    while ((len(m) * 8) + 64) % 512 != 0:
        m.append(0x00)
    m += struct.pack('>Q', length_bits)
    return bytes(m)

def sha256_compress_block(block, H):
    """
    Compression function processing one 512-bit block.
    Implements message schedule, Ch, Maj, Σ0, Σ1, and 64 rounds.
    """
    w = list(struct.unpack('>16L', block))
    for j in range(16, 64):
        s0 = rightrotate(w[j-15], 7) ^ rightrotate(w[j-15], 18) ^ (w[j-15] >> 3)
        s1 = rightrotate(w[j-2], 17) ^ rightrotate(w[j-2], 19) ^ (w[j-2] >> 10)
        w.append((w[j-16] + s0 + w[j-7] + s1) & 0xffffffff)

    a, b, c, d, e, f, g, h = H
    for j in range(64):
        S1 = rightrotate(e, 6) ^ rightrotate(e, 11) ^ rightrotate(e, 25)
        ch = (e & f) ^ ((~e) & g)
        temp1 = (h + S1 + ch + K[j] + w[j]) & 0xffffffff
        S0 = rightrotate(a, 2) ^ rightrotate(a, 13) ^ rightrotate(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        temp2 = (S0 + maj) & 0xffffffff

        h = g
        g = f
        f = e
        e = (d + temp1) & 0xffffffff
        d = c
        c = b
        b = a
        a = (temp1 + temp2) & 0xffffffff

    return [(H[i] + val) & 0xffffffff for i, val in enumerate([a, b, c, d, e, f, g, h])]

def sha256(message):
    """High-level SHA-256 function returning 64-character hex digest."""
    if isinstance(message, str):
        message = message.encode('utf-8')
    padded = sha256_padding(message)
    H = H_INIT.copy()
    for i in range(0, len(padded), 64):
        H = sha256_compress_block(padded[i:i+64], H)
    return ''.join(f'{x:08x}' for x in H)

# PART B: Security Analysis

def avalanche_effect_sha256(message):
    """Measure avalanche effect: flip 1 bit in message and compute % changed bits."""
    print("\n--- SHA-256 Avalanche Effect Test ---")
    if isinstance(message, str):
        mbytes = bytearray(message.encode('utf-8'))
    else:
        mbytes = bytearray(message)
    if len(mbytes) == 0:
        mbytes = bytearray(b'\x00')
    original_hash = sha256(bytes(mbytes))
    # flip lowest bit of first byte
    mbytes[0] ^= 1
    modified_hash = sha256(bytes(mbytes))
    diff_bits = sum(bin(a ^ b).count('1') for a, b in zip(bytes.fromhex(original_hash), bytes.fromhex(modified_hash)))
    print("Original hash :", original_hash)
    print("Modified hash :", modified_hash)
    print(f"Different bits : {diff_bits} / 256  ({diff_bits/256*100:.2f}%)")

def collision_test_sha256(trials=3000):
    """Small-scale random collision test (demonstration)."""
    print("\n--- SHA-256 Collision Test (small-scale) ---")
    seen = {}
    for _ in range(trials):
        msg = str(random.randint(0, 10**12))
        h = sha256(msg)
        if h in seen:
            print("Collision found between messages:", msg, "and", seen[h], "->", h)
            return
        seen[h] = msg
    print("No collisions found after", trials, "random attempts (expected for SHA-256).")

def performance_sha256():
    """Benchmark SHA-256 on several input sizes (printed in ms)."""
    print("\n--- SHA-256 Performance (timings) ---")
    for size in [1, 10, 100, 1000, 5000]:
        data = 'a' * size
        t0 = time.time()
        sha256(data)
        t1 = time.time()
        print(f"Input {size} bytes -> {(t1 - t0)*1000:.3f} ms")

# PART C: MERKLE TREE (with proofs)

class MerkleTree:
    """
    Simple binary Merkle tree:
    - Leaves: sha256(data_block)
    - Internal nodes: sha256(left_hash + right_hash) where + denotes concatenation of hex strings
    - If odd number of nodes at a level, duplicate the last node.
    """
    def __init__(self, blocks):
        self.blocks = blocks
        # compute leaf hashes from block values (strings)
        self.leaves = [sha256(b if isinstance(b, bytes) else str(b)) for b in blocks]
        self.levels = [self.leaves]
        self.build_tree()

    def build_tree(self):
        cur = self.leaves
        while len(cur) > 1:
            nxt = []
            for i in range(0, len(cur), 2):
                left = cur[i]
                right = cur[i+1] if i+1 < len(cur) else cur[i]
                nxt.append(sha256(left + right))
            self.levels.append(nxt)
            cur = nxt
        self.root = cur[0] if cur else None

    def print_tree(self):
        print("\n--- Merkle Tree ---")
        for lvl, nodes in enumerate(self.levels):
            print(f"Level {lvl} ({len(nodes)} nodes):")
            for node in nodes:
                print(" ", node)
        print("Root:", self.root)

    def get_proof(self, index):
        """
        Return proof (authentication path) for leaf at 'index'.
        Proof is list of (sibling_hash, position) tuples where position in {'left','right'}
        meaning sibling is to left or right of the current node when forming the parent.
        """
        proof = []
        idx = index
        for level in self.levels[:-1]:
            sibling_idx = idx ^ 1
            if sibling_idx < len(level):
                sibling_hash = level[sibling_idx]
            else:
                sibling_hash = level[idx]  # duplicate last when odd
            pos = 'left' if sibling_idx < idx else 'right'
            proof.append((sibling_hash, pos))
            idx //= 2
        return proof

    def verify_proof(self, leaf_value, proof, root):
        """
        Verify proof:
        - leaf_value: original block (string) OR leaf hash (hex string)
        - proof: list of (sibling_hash, pos)
        - root: expected root hash hex string
        Returns True if proof validates to root, else False.
        """
        # If leaf_value appears to be a raw leaf-hash hex, use it; else compute hash of block.
        if isinstance(leaf_value, str) and len(leaf_value) == 64 and all(c in '0123456789abcdef' for c in leaf_value):
            h = leaf_value
        else:
            h = sha256(leaf_value)
        for sibling_hash, pos in proof:
            if pos == 'left':
                h = sha256(sibling_hash + h)
            else:
                h = sha256(h + sibling_hash)
        return h == root

# SHA-3 (Keccak) - Sponge construction

# Keccak-f[1600] constants and rotation offsets

RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008
]

r = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14]
]

def rotl64(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)

def keccak_f1600(state):
    """Keccak-f[1600] permutation: 24 rounds on 25 lanes (64-bit each)."""
    for rnd in range(24):
        # Theta step
        C = [state[x] ^ state[x+5] ^ state[x+10] ^ state[x+15] ^ state[x+20] for x in range(5)]
        D = [C[(x-1) % 5] ^ rotl64(C[(x+1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(0, 25, 5):
                state[x + y] ^= D[x]
        # Rho and Pi
        newstate = [0]*25
        for x in range(5):
            for y in range(5):
                newstate[y + ((2*x + 3*y) % 5)*5] = rotl64(state[x + 5*y], r[x][y])
        # Chi
        for x in range(5):
            for y in range(5):
                idx = x + 5*y
                state[idx] = newstate[idx] ^ ((~newstate[((x+1) % 5) + 5*y]) & newstate[((x+2) % 5) + 5*y])
        # Iota
        state[0] ^= RC[rnd]
    return state

def keccak_pad10star1(rate_bytes, message_bytes):
    """
    pad10*1 with domain separation (0x06) for SHA-3:
    - append 0x06, zeros, then 0x80 such that total length is multiple of rate_bytes.
    """
    pad_len = rate_bytes - (len(message_bytes) % rate_bytes)
    if pad_len == 1:
        return message_bytes + bytes([0x86])  # 0x06 and final 0x80 combined
    return message_bytes + bytes([0x06]) + bytes(pad_len - 2) + bytes([0x80])

def sponge_sha3_256(message):
    """
    SHA3-256 implemented via Keccak sponge construction.
    Returns 256-bit digest as 64-char hex string.
    """
    if isinstance(message, str):
        message = message.encode('utf-8')
    rate_bytes = 136  # 1088 bits / 8
    padded = keccak_pad10star1(rate_bytes, message)
    state = [0] * 25  # 25 lanes of 64 bits
    # Absorb
    for i in range(0, len(padded), rate_bytes):
        block = padded[i:i+rate_bytes]
        for j in range(rate_bytes // 8):
            lane = int.from_bytes(block[j*8:(j+1)*8], 'little')
            state[j] ^= lane
        state = keccak_f1600(state)
    # Squeeze
    out = b''
    while len(out) < 32:
        for j in range(rate_bytes // 8):
            out += state[j].to_bytes(8, 'little')
        if len(out) >= 32:
            break
        state = keccak_f1600(state)
    return out[:32].hex()


def full_menu():
    while True:
        print("1) SHA-256 Hash Generation ")
        print("2) SHA-256 Security Analysis ")
        print("3) Merkle Tree Operations & Proofs ")
        print("4) SHA-3 (Keccak) sponge construction (SHA3-256)")
        print("5) Quit")
        choice = input("Enter choice: ").strip()

        if choice == '1':
            msg = input("Enter message to hash (SHA-256): ")
            print("\nSHA-256:", sha256(msg))

        elif choice == '2':
            msg = input("Message for security tests (SHA-256): ")
            avalanche_effect_sha256(msg)
            collision_test_sha256(3000)
            performance_sha256()

        elif choice == '3':
            n = int(input("Number of data blocks for Merkle Tree (>=1): "))
            blocks = [input(f"Block {i+1}: ") for i in range(n)]
            tree = MerkleTree(blocks)
            tree.print_tree()
            # Print Merkle proofs for all leaves (useful for report)
            print("\n--- Merkle Proofs for all leaves ---")
            for i, block in enumerate(blocks):
                proof = tree.get_proof(i)
                verified = tree.verify_proof(block, proof, tree.root)
                print(f"\nLeaf {i+1} (value: {block})")
                print(" Leaf-hash:", tree.leaves[i])
                print(" Proof (sibling_hash, position):", proof)
                print(" Verified:", verified)

        elif choice == '4':
            msg = input("Enter message to hash (SHA3-256): ")
            print("\nSHA3-256 (Keccak sponge):", sponge_sha3_256(msg))

        elif choice == '5':
            print("Exiting.")
            break

        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    full_menu()
