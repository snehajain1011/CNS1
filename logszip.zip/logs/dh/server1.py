import socket
import threading

clients = {}       # username(lower) -> socket
public_keys = {}   # username(lower) -> (e, n)

def handle_client(conn, addr):
    name = None
    try:
        while True:
            raw = conn.recv(65536)
            if not raw:
                break
            msg = raw.decode()
            parts = msg.strip().split(maxsplit=2)
            if not parts:
                continue
            cmd = parts[0].upper()

            if cmd == "REGISTER":
                rest = msg.strip().split()
                if len(rest) < 4:
                    conn.send("ERROR Malformed REGISTER\n".encode())
                    continue
                _, name_raw, e_str, n_str = rest[:4]
                name = name_raw.strip().lower()
                public_keys[name] = (int(e_str), int(n_str))
                clients[name] = conn
                conn.send(f"[SERVER] Registered as {name}\n".encode())
                print(f"[SERVER] {name} registered with key {public_keys[name]}")

            elif cmd == "GET":
                if len(parts) < 2:
                    conn.send("ERROR Malformed GET\n".encode())
                    continue
                target = parts[1].strip().lower()
                if target in public_keys:
                    e, n = public_keys[target]
                    conn.send(f"PUBKEY {target} {e} {n}\n".encode())
                else:
                    conn.send(f"ERROR No such user {target}\n".encode())

            elif cmd == "SET_KEY":
                if len(parts) < 3:
                    conn.send("ERROR Malformed SET_KEY\n".encode())
                    continue
                target = parts[1].strip().lower()
                rest_payload = msg.split(" ", 2)[2]
                if target in clients:
                    try:
                        # forward preserving payload but use lowercase sender name
                        clients[target].sendall(f"SET_KEY {name} {rest_payload}\n".encode())
                        print(f"[SERVER] {name} -> {target} | forwarded SET_KEY")
                    except Exception as e:
                        conn.send(f"ERROR Could not deliver key to {target}\n".encode())
                        print("[SERVER] SET_KEY forward error:", e)
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            elif cmd == "SEND":
                if len(parts) < 3:
                    conn.send("ERROR Malformed SEND\n".encode())
                    continue
                target = parts[1].strip().lower()
                rest_payload = msg.split(" ", 2)[2]
                if target in clients:
                    try:
                        clients[target].sendall(f"FROM {name} {rest_payload}\n".encode())
                        print(f"[SERVER] {name} -> {target} | forwarded SEND")
                    except Exception as e:
                        conn.send(f"ERROR Could not deliver to {target}\n".encode())
                        print("[SERVER] SEND forward error:", e)
                else:
                    conn.send(f"ERROR {target} not connected\n".encode())

            else:
                conn.send("ERROR Unknown command\n".encode())
    except Exception as ex:
        print("[SERVER] Error in handler:", ex)
    finally:
        if name and name in clients and clients[name] is conn:
            del clients[name]
            print(f"[SERVER] Removed client {name}")
        conn.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 6001))
    server.listen(10)
    print("[SERVER] Listening on 127.0.0.1:6001")
    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == "__main__":
    start_server()
