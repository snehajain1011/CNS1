import socket
import threading
import random
import json
import os
import time

# ---------- RSA helpers ----------
def power(base, expo, mod):
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    for d in range(2, phi):
        if (e * d) % phi == 1:
            return d
    return -1

def generate_keys(user):
    u = user.lower()
    if u == "alice":
        p, q = 61, 53
    elif u == "bob":
        p, q = 71, 67
    elif u == "charlie":
        p, q = 73, 59
    else:
        p, q = 79, 83
    n = p * q
    phi = (p - 1) * (q - 1)
    e = 3
    while gcd(e, phi) != 1:
        e += 2
    d = mod_inverse(e, phi)
    return (e, d, n)

def rsa_encrypt_int(m, e, n):
    return power(m, e, n)

def rsa_decrypt_int(c, d, n):
    return power(c, d, n)

def message_to_int(msg, n):
    acc = 0
    for ch in msg:
        acc = (acc * 257 + ord(ch)) % n
    return acc

# ---------- Vigenere ----------
def vigenere_encrypt(text, key):
    out = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('a')
            k = ord(key[i % len(key)]) - base
            out.append(chr((ord(ch) - base + k) % 26 + base))
        else:
            out.append(ch)
    return ''.join(out)

def vigenere_decrypt(text, key):
    out = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('a')
            k = ord(key[i % len(key)]) - base
            out.append(chr((ord(ch) - base - k) % 26 + base))
        else:
            out.append(ch)
    return ''.join(out)

def derive_key(secret, length=250):
    out = []
    for i in range(length):
        out.append(chr((secret + 7 * i) % 26 + ord('a')))
    return ''.join(out)

# ---------- Diffie-Hellman ----------
DH_P = 3079
DH_G = 5

# ---------- Networking ----------
SERVER = ("127.0.0.1", 6001)
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect(SERVER)

username_raw = input("Enter username (alice/bob/charlie/...): ").strip()
username = username_raw.lower()

e, d, n = generate_keys(username)
sock.sendall(f"REGISTER {username} {e} {n}".encode())

keyring_file = f"keyring_{username}.json"
keyring = json.load(open(keyring_file)) if os.path.exists(keyring_file) else {}

session_keys = {}
dh_ephemeral = {}

# ---------- Receiver ----------
def receive_loop():
    while True:
        try:
            raw = sock.recv(65536)
            if not raw:
                break
            msg = raw.decode().rstrip("\n")
            if not msg:
                continue

            if msg.startswith("PUBKEY"):
                parts = msg.split()
                if len(parts) >= 4:
                    _, user, e1, n1 = parts[:4]
                    user = user.lower()
                    keyring[user] = [int(e1), int(n1)]
                    with open(keyring_file, "w") as f:
                        json.dump(keyring, f)
                    print(f"[INFO] Saved PUBKEY for {user}")

            elif msg.startswith("SET_KEY"):
                try:
                    _, sender, payload = msg.split(maxsplit=2)
                except ValueError:
                    print("[RECV] Malformed SET_KEY")
                    continue
                sender = sender.lower()
                toks = payload.split()
                if len(toks) < 3:
                    print("[RECV] Malformed SET_KEY payload")
                    continue
                typ = toks[0]
                try:
                    c1 = int(toks[1]); c2 = int(toks[2])
                except:
                    print("[RECV] Non-integer in SET_KEY")
                    continue

                # ensure pubkey present
                if sender not in keyring:
                    sock.sendall(f"GET {sender}".encode())
                    time.sleep(0.15)
                sender_pub = keyring.get(sender)
                if sender_pub is None:
                    print(f"[RECV] Missing pubkey for {sender}; cannot verify")
                    continue
                e_s, n_s = sender_pub

                if typ == "DH_A":
                    A = rsa_decrypt_int(c1, d, n)
                    sigA = rsa_decrypt_int(c2, d, n)
                    print(f"[DEBUG] Received DH_A from {sender}: A={A}, sigA={sigA}")
                    # verify: sigA^e_s mod n_s == A
                    if rsa_encrypt_int(sigA, e_s, n_s) == A:
                        b = random.randint(2, DH_P - 2)
                        B = pow(DH_G, b, DH_P)
                        sigB = rsa_encrypt_int(B, d, n)
                        cB = rsa_encrypt_int(B, e_s, n_s)
                        cSB = rsa_encrypt_int(sigB, e_s, n_s)
                        sock.sendall(f"SET_KEY {sender} DH_B {cB} {cSB}".encode())
                        shared = pow(A, b, DH_P)
                        session_keys[sender] = derive_key(shared)
                        print(f"[HANDSHAKE] Completed (responder) with {sender}")
                    else:
                        print("[HANDSHAKE] Signature verification failed for DH_A")
                        print(f"[DEBUG-VERIFY] Checking sigA^{e_s} mod n_s = {rsa_encrypt_int(sigA, e_s, n_s)} vs A={A}")

                elif typ == "DH_B":
                    B = rsa_decrypt_int(c1, d, n)
                    sigB = rsa_decrypt_int(c2, d, n)
                    print(f"[DEBUG] Received DH_B from {sender}: B={B}, sigB={sigB}")
                    if rsa_encrypt_int(sigB, e_s, n_s) == B:
                        a = dh_ephemeral.pop(sender, None)
                        if a is None:
                            print("[HANDSHAKE] Missing ephemeral 'a' for", sender)
                            continue
                        shared = pow(B, a, DH_P)
                        session_keys[sender] = derive_key(shared)
                        print(f"[HANDSHAKE] Completed (initiator) with {sender}")
                    else:
                        print("[HANDSHAKE] Signature verification failed for DH_B")
                        print(f"[DEBUG-VERIFY] Checking sigB^{e_s} mod n_s = {rsa_encrypt_int(sigB, e_s, n_s)} vs B={B}")

            elif msg.startswith("FROM"):
                try:
                    _, sender, payload = msg.split(maxsplit=2)
                except ValueError:
                    print("[FROM] Malformed FROM")
                    continue
                sender = sender.lower()
                parts = payload.split(maxsplit=1)
                if len(parts) < 2:
                    print("[FROM] Malformed payload")
                    continue
                sig_str, ciphertext = parts
                try:
                    sig_int = int(sig_str)
                except:
                    print("[FROM] Invalid signature int")
                    continue

                if sender not in session_keys:
                    print(f"[ERROR] No session key with {sender}; run HANDSHAKE first")
                    continue

                key = session_keys[sender]
                plaintext = vigenere_decrypt(ciphertext, key)
                print("\n------------------------------")
                print(f"Message from {sender}:")
                print(plaintext)
                print("------------------------------\n")

            else:
                print(msg)

        except Exception as ex:
            print("[RECV ERROR]", ex)
            break

threading.Thread(target=receive_loop, daemon=True).start()

# ---------- helpers ----------
def ensure_pubkey(user, timeout=2.0):
    user = user.lower()
    if user in keyring:
        return tuple(keyring[user])
    sock.sendall(f"GET {user}".encode())
    waited = 0.0
    interval = 0.05
    while waited < timeout:
        if user in keyring:
            return tuple(keyring[user])
        time.sleep(interval)
        waited += interval
    return None

def do_handshake(target):
    target = target.lower()
    pub = ensure_pubkey(target, timeout=2.0)
    if not pub:
        print(f"[HANDSHAKE] No public key for {target}; try GET {target} and wait")
        return
    e_t, n_t = pub
    a = random.randint(2, DH_P - 2)
    A = pow(DH_G, a, DH_P)
    sigA = rsa_encrypt_int(A, d, n)
    cA = rsa_encrypt_int(A, e_t, n_t)
    cSigA = rsa_encrypt_int(sigA, e_t, n_t)
    dh_ephemeral[target] = a
    sock.sendall(f"SET_KEY {target} DH_A {cA} {cSigA}".encode())
    print(f"[HANDSHAKE] Sent DH_A to {target}; waiting for DH_B...")

def send_text(target, text):
    target = target.lower()
    if target not in session_keys:
        print("Run HANDSHAKE first!")
        return
    key = session_keys[target]
    cipher = vigenere_encrypt(text, key)
    m_int = message_to_int(text, n)
    sig_int = rsa_encrypt_int(m_int, d, n)
    sock.sendall(f"SEND {target} {sig_int} {cipher}".encode())
    print("[SENT] Encrypted message sent")

# ---------- main ----------
keyring = json.load(open(keyring_file)) if os.path.exists(keyring_file) else {}
print("Commands: GET <user>, HANDSHAKE <user>, SEND <user> <message>, QUIT")
while True:
    try:
        cmd = input(">").strip()
    except (KeyboardInterrupt, EOFError):
        print("Exiting.")
        sock.close()
        break
    if not cmd:
        continue
    parts = cmd.split(maxsplit=2)
    op = parts[0].upper()
    if op == "GET" and len(parts) >= 2:
        pub = ensure_pubkey(parts[1], timeout=2.0)
        if pub:
            print(f"[GET] Pubkey for {parts[1].lower()} available")
        else:
            print(f"[GET] Request sent; pubkey not received yet")
    elif op == "HANDSHAKE" and len(parts) >= 2:
        do_handshake(parts[1])
    elif op == "SEND" and len(parts) >= 3:
        send_text(parts[1], parts[2])
    elif op == "QUIT":
        sock.close()
        break
    else:
        print("Commands: GET <user>, HANDSHAKE <user>, SEND <user> <message>, QUIT")
