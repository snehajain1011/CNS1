import socket
import threading

# ----- Diffie–Hellman parameters -----
p = 23   # prime
g = 5    # primitive root

def handle_client(conn, addr, a):
    print("Client connected:", addr)

    # Compute A = g^a mod p
    A = pow(g, a, p)

    # Send p, g, A to Bob
    conn.send(f"{p},{g},{A}".encode())

    # Receive Bob's public value B
    B = int(conn.recv(1024).decode())

    # Compute shared key
    shared_key = pow(B, a, p)
    print("\nShared key computed by Alice:", shared_key)

    conn.send(b"Key exchange complete")
    conn.close()


def main():
    # Ask Alice for her secret exponent
    a = int(input("Enter Alice's secret exponent (a): "))

    print(f"Alice using secret exponent a = {a}")

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", 5000))
    server.listen(1)

    print("\nServer waiting for connection on port 5000...")
    while True:
        conn, addr = server.accept()
        handle_client(conn, addr, a)


if __name__ == "__main__":
    main()
