import socket
import threading
import random
import json
import os
from time import time

# Modular exponentiation (base^expo mod mod)
def power(base, expo, mod):
    result = 1
    base %= mod
    while expo > 0:
        if expo & 1:
            result = (result * base) % mod
        base = (base * base) % mod
        expo //= 2
    return result

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

# Generate RSA key pair (public: (e, n), private: (d, n))
def mod_inverse(e, phi):
    for d in range(2, phi):
        if (e * d) % phi == 1:
            return d
    return -1

def generate_keys(user):
    # deterministic small primes per identity (for reproducibility in the lab)
    if user.lower() == "alice": p, q = 61, 53
    elif user.lower() == "bob": p, q = 71, 67
    elif user.lower() == "charlie": p, q = 73, 59
    else: p, q = 79, 83
    n = p * q
    phi = (p - 1) * (q - 1)
    e = 3
    while e < phi and gcd(e, phi) != 1:
        e += 2
    d = mod_inverse(e, phi)
    return (e, d, n)


# Encrypt integer using RSA
def rsa_encrypt_int(m, e, n):
    return power(m, e, n)
# Decrypt integer using RSA
def rsa_decrypt_int(c, d, n):
    return power(c, d, n)

# Simple Vigenere symmetric cipher (alphabetic)
def vigenere_encrypt(text, key):
    cipher = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % len(key)].lower()) - ord('a')
            cipher.append(chr((ord(ch)-base+shift)%26+base))
        else:
            cipher.append(ch)
    return ''.join(cipher)

def vigenere_decrypt(text, key):
    plain = []
    for i, ch in enumerate(text):
        if ch.isalpha():
            base = ord('A') if ch.isupper() else ord('a')
            shift = ord(key[i % len(key)].lower()) - ord('a')
            plain.append(chr((ord(ch)-base-shift)%26+base))
        else:
            plain.append(ch)
    return ''.join(plain)

# Derive symmetric Vigenère key from shared DH secret
def derive_key_from_secret(secret, length=250):
    out_chars = []
    counter = 0
    while len(out_chars) < length:
        val = (secret + counter * 7) % 26
        out_chars.append(chr(val + ord('a')))
        counter += 1
    return ''.join(out_chars)

# Map full plaintext to integer (modulo n) to sign/verify
def message_to_int(msg, n):
    acc = 0
    for ch in msg:
        acc = (acc * 257 + ord(ch)) % n
    return acc  

# Diffie-Hellman Public Parameters
DH_P = 3079         # prime modulus
DH_G = 5         # generator

# Connect to server and initialize keys
SERVER_ADDR = ("127.0.0.1", 6001)
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(SERVER_ADDR)



# Setup RSA keys and register
username = input("Enter username (alice/bob/charlie/david): ").strip().lower()
e, d, n = generate_keys(username)
public_key = (e, n)
private_key = (d, n)
client.send(f"REGISTER {username} {e} {n}".encode())

keyring_file = f"keyring_{username}.json"
if os.path.exists(keyring_file):
    with open(keyring_file, "r", encoding="utf-8") as f:
        keyring = json.load(f)
else:
    keyring = {}

# sessions and ephemeral DH storage
symmetric_keys = {}     # peer -> symmetric key string
dh_ephemeral = {}       # peer -> ephemeral secret exponent 'a' when we initiated
dh_A_store = {}         # peer -> our A if needed

io_log = f"io_log_{username}.txt"
def log(s):
    print(s)
    with open(io_log, "a") as f:
        f.write(f"{time():.3f} {s}\n")

# Incoming message handler thread
def receive_messages():
    global keyring, symmetric_keys, dh_ephemeral, dh_A_store
    while True:
        try:
            raw = client.recv(65536)
            if not raw:
                break
            msg = raw.decode().strip()
            if not msg:
                continue

            if msg.startswith("PUBKEY"):
                # PUBKEY <target> <e> <n>
                _, target, e_str, n_str = msg.split()
                keyring[target] = [int(e_str), int(n_str)]
                with open(keyring_file, "w") as f:
                    json.dump(keyring, f)
                log(f"[INFO] Received & saved PUBKEY {target} -> {keyring[target]}")

            elif msg.startswith("SET_KEY"):
                # SET_KEY <sender> <payload...>
                _, sender, payload = msg.split(maxsplit=2)
                toks = payload.strip().split()
                # Expect format: TYPE <c1> <c2>
                if len(toks) < 3:
                    log(f"[SET_KEY] Malformed payload from {sender}")
                    continue
                typ = toks[0]
                try:
                    c1 = int(toks[1]); c2 = int(toks[2])
                except:
                    log("[SET_KEY] Non-integer payload")
                    continue

                # ensure we have sender's public key
                if sender not in keyring:
                    client.send(f"GET {sender}".encode())
                    log(f"[SET_KEY] Requested pubkey for {sender}")
                    import time as _t; _t.sleep(0.2)
                sender_pub = keyring.get(sender)
                if sender_pub is None:
                    log(f"[SET_KEY] No pubkey for {sender}; cannot verify")
                    continue
                e_s, n_s = sender_pub

                if typ == "DH_A":
                    # We're the receiver (Bob). Decrypt Alice's A and sig.
                    A = rsa_decrypt_int(c1, *private_key)
                    sigA = rsa_decrypt_int(c2, *private_key)
                    # verify signature: sigA^e_s mod n_s == A
                    if rsa_decrypt_int(sigA, e_s, n_s) == A:
                        log(f"[HANDSHAKE] Received valid DH_A from {sender}: A={A}")
                        # Generate our ephemeral b and B
                        b = random.randint(2, DH_P - 2)
                        B = pow(DH_G, b, DH_P)
                        # sign B with our private key
                        sigB = rsa_encrypt_int(B, d, n)
                        # encrypt B and sigB with sender's public key
                        cB = rsa_encrypt_int(B, e_s, n_s)
                        cSigB = rsa_encrypt_int(sigB, e_s, n_s)
                        # send back DH_B
                        client.sendall(f"SET_KEY {sender} DH_B {cB} {cSigB}".encode())
                        log(f"[HANDSHAKE] Sent DH_B to {sender}: B={B}")
                        # derive shared secret = A^b mod p
                        shared = pow(A, b, DH_P)
                        symmetric_keys[sender] = derive_key_from_secret(shared, 250)
                        log(f"[HANDSHAKE] Derived symmetric key for session with {sender} (len={len(symmetric_keys[sender])})")
                    else:
                        log(f"[HANDSHAKE] Signature verification FAILED for DH_A from {sender}")

                elif typ == "DH_B":
                    # We're the initiator (Alice). Decrypt B and sigB.
                    B = rsa_decrypt_int(c1, *private_key)
                    sigB = rsa_decrypt_int(c2, *private_key)
                    # verify signature using sender's pubkey (which is Bob)
                    if rsa_decrypt_int(sigB, e_s, n_s) == B:
                        log(f"[HANDSHAKE] Received valid DH_B from {sender}: B={B}")
                        # retrieve our ephemeral 'a' that we stored
                        a = dh_ephemeral.get(sender)
                        # clear ephemeral
                        dh_ephemeral.pop(sender, None)
                        if a is None:
                            log(f"[HANDSHAKE] Missing ephemeral secret 'a' for {sender}; cannot compute shared key")
                            continue
                        shared = pow(B, a, DH_P)
                        symmetric_keys[sender] = derive_key_from_secret(shared, 250)
                        log(f"[HANDSHAKE] Derived symmetric key for session with {sender} (len={len(symmetric_keys[sender])})")
                    else:
                        log(f"[HANDSHAKE] Signature verification FAILED for DH_B from {sender}")

                else:
                    log(f"[SET_KEY] Unknown type {typ} from {sender}")

            elif msg.startswith("FROM"):
                # FROM <sender> <sig_int> <ciphertext...>
                _, sender, payload = msg.split(maxsplit=2)
                parts = payload.split(maxsplit=1)
                if len(parts) < 2:
                    log(f"[FROM] Malformed FROM from {sender}")
                    continue
                sig_str, ciphertext = parts
                try:
                    sig_int = int(sig_str)
                except:
                    log("[FROM] Invalid signature integer format")
                    continue
                if sender not in symmetric_keys:
                    log(f"[FROM] No symmetric key for {sender}; cannot decrypt")
                    continue
                key = symmetric_keys[sender]
                plaintext = vigenere_decrypt(ciphertext, key)
                # verify signature: compute message->int modulo sender's n and check sig^e == m_int
                sender_pub = keyring.get(sender)
                if sender_pub is None:
                    log(f"[FROM] Missing pubkey for {sender}; requesting")
                    client.send(f"GET {sender}".encode())
                    import time as _t; _t.sleep(0.2)
                    sender_pub = keyring.get(sender)
                    if sender_pub is None:
                        log(f"[FROM] Cannot verify signature for {sender} (no pubkey)")
                        verified = False
                    else:
                        e_s, n_s = sender_pub
                        m_int = message_to_int(plaintext, n_s)
                        verified = (rsa_decrypt_int(sig_int, e_s, n_s) == m_int)
                else:
                    e_s, n_s = sender_pub
                    m_int = message_to_int(plaintext, n_s)
                    verified = (rsa_decrypt_int(sig_int, e_s, n_s) == m_int)

                # save plaintext to file and log verification
                fname = f"received_from_{sender}.txt"
                with open(fname, "w", encoding="utf-8") as f:
                    f.write(plaintext)
                log(f"[MESSAGE] From {sender}: saved to {fname}; signature_verified={verified}")

            else:
                log(f"[SERVER] {msg}")

        except Exception as ex:
            log(f"[Receiver Error] {ex}")
            break

threading.Thread(target=receive_messages, daemon=True).start()

# Retrieve public key of target
def ensure_pubkey(target):
    if target in keyring:
        return tuple(keyring[target])
    client.send(f"GET {target}".encode())
    log(f"[GET] Requested public key for {target}")
    import time as _t; _t.sleep(0.3)
    return tuple(keyring[target]) if target in keyring else None


# Initiate RSA-authenticated Diffie-Hellman Handshake
def command_HANDSHAKE(target):
    pub = ensure_pubkey(target)
    if not pub:
        log(f"[HANDSHAKE] No pubkey for {target}")
        return
    e_t, n_t = pub
    # generate ephemeral secret a and compute A = g^a mod p
    a = random.randint(2, DH_P - 2)
    A = pow(DH_G, a, DH_P)
    # sign A with our private RSA key
    sigA = rsa_encrypt_int(A, d, n)
    # encrypt A and sigA with receiver's public key
    cA = rsa_encrypt_int(A, e_t, n_t)
    cSigA = rsa_encrypt_int(sigA, e_t, n_t)
    client.sendall(f"SET_KEY {target} DH_A {cA} {cSigA}".encode())
    log(f"[HANDSHAKE] Sent DH_A to {target}: A={A} (ephemeral a kept locally)")
    # store ephemeral a so when DH_B arrives we can compute shared = B^a mod p
    dh_ephemeral[target] = a
    dh_A_store[target] = A

def command_SEND_TEXT(target, text):
    if target not in symmetric_keys:
        log(f"[SEND] No session key for {target}. Run HANDSHAKE first.")
        return
    key = symmetric_keys[target]
    cipher = vigenere_encrypt(text, key)
    m_int = message_to_int(text, n)
    sig_int = rsa_encrypt_int(m_int, d, n)
    payload = f"{sig_int} {cipher}"
    client.sendall(f"SEND {target} {payload}".encode())
    log(f"[SENT] Plaintext (first 200 chars): {text[:200]}")
    log(f"[SENT] Signature int: {sig_int}")
    log(f"[SENT] Encrypted text (cipher, first 200 chars): {cipher[:200]}")

def command_SEND_FILE(target, filename):
    try:
        text = open(filename, "r", encoding="utf-8").read()
    except FileNotFoundError:
        log(f"[SEND_FILE] File not found: {filename}")
        return
    command_SEND_TEXT(target, text)
    log(f"[SEND_FILE] Sent file {filename} to {target}")

help_text = """
Available commands:
  GET <user>                 - request public key
  HANDSHAKE <user>           - initiate authenticated DH handshake
  SEND_TEXT <user> <text>    - send signed+encrypted text (session required)
  SEND_FILE <user> <path>    - send signed+encrypted file (session required)
  KEYS                       - show local keyring
  SESSIONS                   - show symmetric sessions
  QUIT                       - exit
"""

log(f"[START] User '{username}' running. Public key (e,n)={public_key}")

while True:
    try:
        cmd = input("Enter command (HELP for options): ").strip()
    except (KeyboardInterrupt, EOFError):
        cmd = "QUIT"
    if not cmd:
        continue
    parts = cmd.split(maxsplit=2)
    op = parts[0].upper()
    if op == "HELP":
        print(help_text)
    elif op == "GET" and len(parts) >= 2:
        ensure_pubkey(parts[1])
    elif op == "HANDSHAKE" and len(parts) >= 2:
        command_HANDSHAKE(parts[1])
    elif op == "SEND_TEXT" and len(parts) >= 3:
        command_SEND_TEXT(parts[1], parts[2])
    elif op == "SEND_FILE" and len(parts) >= 3:
        command_SEND_FILE(parts[1], parts[2])
    elif op == "KEYS":
        print(json.dumps(keyring, indent=2))
    elif op == "SESSIONS":
        print("sessions:", list(symmetric_keys.keys()))
    elif op == "QUIT":
        log("[QUIT] Exiting.")
        client.close()
        break
    else:
        log("[ERROR] Unknown command. Type HELP")
