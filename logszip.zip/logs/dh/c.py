import socket

def main():
    # Ask Bob for his secret exponent
    b = int(input("Enter Bob's secret exponent (b): "))

    print(f"Bob using secret exponent b = {b}")

    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(("127.0.0.1", 5000))

    # Receive p, g, A from Alice
    p, g, A = map(int, client.recv(1024).decode().split(","))

    # Compute B = g^b mod p
    B = pow(g, b, p)

    # Send B to Alice
    client.send(str(B).encode())

    # Compute shared key
    shared_key = pow(A, b, p)
    print("\nShared key computed by Bob:", shared_key)

    print(client.recv(1024).decode())

    client.close()


if __name__ == "__main__":
    main()
